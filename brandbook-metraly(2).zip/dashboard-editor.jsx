// dashboard-editor.jsx — Engineering Intelligence dashboard editor.
// Reframed around DORA + flow + delivery health (PR review latency,
// cycle time, deployment frequency, change failure rate, lead time,
// CI failure rate, flaky builds, blocked work, team delivery health,
// DORA overview).

const { useState: useStateDE, useRef: useRefDE } = React;

// ─── Sidebar ────────────────────────────────────────────────────
function Sidebar({ active, onNav }) {
  const items = [
    { id: "overview",  label: "Overview",       icon: "grid" },
    { id: "delivery",  label: "Delivery",       icon: "metric" },
    { id: "dora",      label: "DORA",           icon: "lightning" },
    { id: "flow",      label: "Flow & WIP",     icon: "chart" },
    { id: "reviews",   label: "Code review",    icon: "log", badge: 3 },
    { id: "ci",        label: "CI health",      icon: "refresh" },
    { id: "incidents", label: "Incidents",      icon: "bell" },
    { id: "teams",     label: "Teams",          icon: "user" },
  ];
  const footer = [
    { id: "settings", label: "Settings",     icon: "settings" },
    { id: "user",     label: "ops@metraly",  icon: "user" },
  ];
  return (
    <aside style={{
      width: 196, flex: "0 0 196px",
      background: "var(--m-bg-1)",
      borderRight: "1px solid var(--m-line)",
      display: "flex", flexDirection: "column",
      padding: "16px 8px",
    }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, padding: "8px 0 16px", borderBottom: "1px solid var(--m-line-faint)", marginBottom: 12 }}>
        <div style={{ position: "relative", display: "inline-flex", alignItems: "center", justifyContent: "center", width: 36, height: 36, borderRadius: 8, background: "var(--m-bg-2)", border: "1px solid var(--m-cyan-500)", boxShadow: "0 0 12px -3px var(--m-cyan-glow)" }}>
            <span style={{ fontFamily: "var(--m-font-mono)", fontSize: 16, fontWeight: 600, color: "var(--m-cyan-500)", lineHeight: 1 }}>M</span>
            <span style={{ position: "absolute", bottom: 4, left: 6, right: 6 }}><PulseWave width={24} height={6} color="var(--m-cyan-500)" /></span>
        </div>
        <div style={{ fontSize: 11, color: "var(--m-fg-1)", fontWeight: 500, letterSpacing: "0.04em" }}>METRALY</div>
        <div style={{ fontSize: 9, color: "var(--m-fg-3)", fontFamily: "var(--m-font-mono)" }}>engineering intelligence</div>
      </div>
      <nav style={{ display: "flex", flexDirection: "column", gap: 1 }}>
        {items.map(it => {
          const isActive = it.id === active;
          return (
            <button key={it.id} className="m-focusable" onClick={() => onNav?.(it.id)}
              style={{
                position: "relative", display: "flex", alignItems: "center", gap: 10,
                padding: "7px 10px",
                background: isActive ? "var(--m-cyan-bg)" : "transparent", border: "none",
                color: isActive ? "var(--m-cyan-500)" : "var(--m-fg-2)",
                fontSize: "var(--m-fs-12)", fontFamily: "var(--m-font-ui)",
                borderRadius: "var(--m-r-2)", cursor: "pointer", textAlign: "left",
                transition: "background var(--m-dur-2), color var(--m-dur-2)",
              }}
              onMouseEnter={(e) => { if (!isActive) { e.currentTarget.style.background = "var(--m-bg-2)"; e.currentTarget.style.color = "var(--m-fg-1)"; } }}
              onMouseLeave={(e) => { if (!isActive) { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "var(--m-fg-2)"; } }}
            >
              {isActive && <span style={{ position: "absolute", left: 0, top: 6, bottom: 6, width: 2, background: "var(--m-cyan-500)", borderRadius: 2, boxShadow: "0 0 8px -1px var(--m-cyan-glow)" }} />}
              <Icon name={it.icon} size={13} />
              <span style={{ flex: 1 }}>{it.label}</span>
              {it.badge && <span style={{ fontFamily: "var(--m-font-mono)", fontSize: 9, color: "var(--m-cyan-500)", background: "var(--m-cyan-bg)", padding: "1px 5px", borderRadius: 999, border: "1px solid var(--m-cyan-500)" }}>{it.badge}</span>}
            </button>
          );
        })}
      </nav>
      <div style={{ flex: 1 }} />
      <div style={{ display: "flex", flexDirection: "column", gap: 1, paddingTop: 12, borderTop: "1px solid var(--m-line-faint)" }}>
        {footer.map(it => (
          <button key={it.id} className="m-focusable" style={{
            display: "flex", alignItems: "center", gap: 10,
            padding: "7px 10px", background: "transparent", border: "none",
            color: "var(--m-fg-2)", fontSize: "var(--m-fs-12)", fontFamily: "var(--m-font-ui)",
            borderRadius: "var(--m-r-2)", cursor: "pointer", textAlign: "left",
          }}><Icon name={it.icon} size={13} /><span>{it.label}</span></button>
        ))}
      </div>
    </aside>
  );
}

// ─── Topbar ─────────────────────────────────────────────────────
const ghostBtn = {
  height: "var(--m-control-h)", padding: "0 10px",
  background: "var(--m-bg-2)", border: "1px solid var(--m-line)",
  color: "var(--m-fg-1)", borderRadius: "var(--m-r-2)",
  fontSize: 11, fontFamily: "var(--m-font-ui)",
  display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer",
  transition: "background var(--m-dur-2), border-color var(--m-dur-2)",
};

function Topbar({ title, breadcrumbs, onTimeChange, time = "14d" }) {
  return (
    <header style={{
      display: "flex", alignItems: "center", gap: 12,
      padding: "10px 18px",
      borderBottom: "1px solid var(--m-line)",
      background: "var(--m-bg-1)", flex: "0 0 auto",
    }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 2, flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 10, color: "var(--m-fg-3)", fontFamily: "var(--m-font-mono)", letterSpacing: "0.04em", textTransform: "uppercase", display: "flex", gap: 6 }}>
          {breadcrumbs.map((b, i) => (
            <React.Fragment key={i}>
              <span>{b}</span>
              {i < breadcrumbs.length - 1 && <span style={{ color: "var(--m-fg-4)" }}>/</span>}
            </React.Fragment>
          ))}
        </div>
        <div style={{ fontSize: "var(--m-fs-16)", color: "var(--m-fg-0)", fontWeight: 500, display: "flex", alignItems: "center", gap: 10 }}>
          {title}
          <span style={{ fontFamily: "var(--m-font-mono)", fontSize: 10, color: "var(--m-fg-3)", letterSpacing: "0.04em" }}>· 14d window · 6 teams</span>
        </div>
      </div>
      <MetralySelect width={170} value={time} onChange={onTimeChange} options={[
        { value: "7d",  label: "Last 7 days" },
        { value: "14d", label: "Last 14 days" },
        { value: "30d", label: "Last 30 days" },
        { value: "90d", label: "Last 90 days" },
      ]} />
      <button className="m-focusable" style={ghostBtn}><Icon name="refresh" size={12} /> Refresh</button>
      <button className="m-focusable" style={ghostBtn}><Icon name="star" size={12} /> Favorite</button>
      <button className="m-focusable" style={ghostBtn}><Icon name="settings" size={12} /></button>
    </header>
  );
}

// ─── WidgetPicker — Engineering Intelligence library ─────────────
function WidgetPicker({ onPick, onClose, draggingId, onDragStart, onDragEnd }) {
  const items = [
    { id: "deploy-freq",   icon: "lightning", title: "Deployment frequency",   kind: "dora/deploy-freq",     description: "Deploys per day, by service & team." },
    { id: "lead-time",     icon: "metric",    title: "Lead time for changes",  kind: "dora/lead-time",       description: "PR opened → prod, p50 / p90." },
    { id: "cfr",           icon: "chart",     title: "Change failure rate",    kind: "dora/cfr",             description: "% of deploys that triggered a rollback or incident." },
    { id: "mttr",          icon: "refresh",   title: "MTTR",                   kind: "dora/mttr",            description: "Time from incident open → resolved." },
    { id: "cycle-time",    icon: "chart",     title: "Cycle time breakdown",   kind: "flow/cycle",           description: "Coding · review · merge · deploy." },
    { id: "review-lat",    icon: "metric",    title: "PR review latency",      kind: "review/latency",       description: "First review response, by team." },
    { id: "ci-fail",       icon: "log",       title: "CI failure rate",        kind: "ci/fail",              description: "Failed pipelines / total pipelines." },
    { id: "flaky",         icon: "lightning", title: "Flaky builds",           kind: "ci/flaky",             description: "Tests retried-then-passed in last 7d.", state: "new" },
    { id: "blocked",       icon: "bell",      title: "Blocked work",           kind: "flow/blocked",         description: "Issues stalled > 3 days, by stage." },
    { id: "team-health",   icon: "user",      title: "Team delivery health",   kind: "team/health",          description: "Composite score per squad." },
    { id: "dora",          icon: "grid",      title: "DORA overview",          kind: "dora/overview",        description: "All four DORA metrics on one card.", state: "new" },
    { id: "incident-feed", icon: "bell",      title: "Incident feed",          kind: "ops/incidents",        description: "Open & recent incidents." },
    { id: "wip",           icon: "table",     title: "WIP per engineer",       kind: "flow/wip",             description: "Source not connected.", state: "disabled" },
  ];
  const [search, setSearch] = useStateDE("");
  const filtered = items.filter(i => i.title.toLowerCase().includes(search.toLowerCase()));
  return (
    <div style={{ width: 320, flex: "0 0 320px", background: "var(--m-bg-1)", borderLeft: "1px solid var(--m-line)", display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "12px 14px 8px", display: "flex", alignItems: "center", gap: 8, borderBottom: "1px solid var(--m-line-faint)" }}>
        <Icon name="grid" size={13} />
        <div style={{ flex: 1, fontSize: "var(--m-fs-12)", color: "var(--m-fg-0)", fontWeight: 500 }}>Widget library</div>
        <button className="m-focusable" onClick={onClose} aria-label="Close picker" style={{ background: "transparent", border: "none", color: "var(--m-fg-3)", cursor: "pointer", padding: 4, borderRadius: 4 }}>
          <Icon name="x" size={12} />
        </button>
      </div>
      <div style={{ padding: "10px 14px", borderBottom: "1px solid var(--m-line-faint)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: "var(--m-bg-2)", border: "1px solid var(--m-line)", borderRadius: "var(--m-r-2)", padding: "0 10px", height: "var(--m-control-h)" }}>
          <Icon name="search" size={12} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Filter widgets…" className="m-focusable"
            style={{ flex: 1, height: "100%", background: "transparent", border: "none", outline: "none", color: "var(--m-fg-1)", fontFamily: "var(--m-font-ui)", fontSize: "var(--m-fs-12)" }} />
        </div>
      </div>
      <div className="m-scroll" style={{ flex: 1, overflow: "auto", padding: 12, display: "flex", flexDirection: "column", gap: 8 }}>
        {filtered.length === 0 ? (
          <div style={{ padding: "24px 12px", textAlign: "center", color: "var(--m-fg-3)", fontSize: "var(--m-fs-11)" }}>No widgets match “{search}”</div>
        ) : filtered.map(i => (
          <div key={i.id} draggable={i.state !== "disabled"}
            onDragStart={(e) => { e.dataTransfer.setData("text/plain", i.id); e.dataTransfer.effectAllowed = "copy"; onDragStart?.(i.id); }}
            onDragEnd={() => onDragEnd?.()}
          >
            <WidgetPickerCard icon={i.icon} title={i.title} kind={i.kind} description={i.description}
              state={draggingId === i.id ? "default" : (i.state || "default")}
              dragging={draggingId === i.id}
              onClick={() => i.state !== "disabled" && onPick?.(i.id)}
            />
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── EI widget bodies ───────────────────────────────────────────
function CycleTimeBars() {
  const segs = [
    { name: "Coding",  hrs: 14.2, color: "var(--m-cyan-500)" },
    { name: "Review",  hrs: 22.6, color: "var(--m-purple-500)" },
    { name: "Merge",   hrs: 3.1,  color: "var(--m-cyan-400)" },
    { name: "Deploy",  hrs: 1.4,  color: "var(--m-purple-400)" },
  ];
  const total = segs.reduce((s, x) => s + x.hrs, 0);
  return (
    <div style={{ flex: 1, padding: 14, display: "flex", flexDirection: "column", gap: 12, minHeight: 0 }}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
        <span style={{ fontFamily: "var(--m-font-mono)", fontSize: 24, color: "var(--m-fg-0)" }}>{total.toFixed(1)}h</span>
        <span style={{ fontSize: 11, color: "var(--m-warn)", fontFamily: "var(--m-font-mono)" }}>▲ 3.2h vs −14d</span>
      </div>
      <div style={{ display: "flex", height: 14, borderRadius: 4, overflow: "hidden", border: "1px solid var(--m-line-faint)" }}>
        {segs.map((s, i) => (
          <div key={i} style={{ flex: s.hrs, background: s.color, opacity: 0.7 }} />
        ))}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
        {segs.map((s, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 10, fontFamily: "var(--m-font-mono)", color: "var(--m-fg-2)" }}>
            <span style={{ width: 8, height: 8, background: s.color, borderRadius: 2, opacity: 0.7 }} />
            <span style={{ flex: 1 }}>{s.name}</span>
            <span style={{ color: "var(--m-fg-1)" }}>{s.hrs.toFixed(1)}h</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function DeployFreqChart({ accent = "cyan" }) {
  const series = [
    { name: "deploys", data: [4, 6, 5, 7, 8, 6, 9, 11, 10, 12, 14, 13, 15, 14, 12, 16, 18, 17, 15, 19, 21, 18, 22, 24] },
    { name: "rollbacks", data: [0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 1] },
  ];
  return (
    <div style={{ flex: 1, padding: 8, display: "flex", flexDirection: "column", minHeight: 0 }}>
      <div style={{ flex: 1, position: "relative", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <ChartLine series={series} width={520} height={180} accent={accent} />
      </div>
      <div style={{ display: "flex", gap: 12, padding: "4px 12px", fontFamily: "var(--m-font-mono)", fontSize: 10, color: "var(--m-fg-3)" }}>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><span style={{ width: 8, height: 2, background: "var(--m-cyan-500)" }} /> deploys 24/day</span>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><span style={{ width: 8, height: 2, background: "var(--m-purple-500)" }} /> rollbacks 1/day</span>
      </div>
    </div>
  );
}

function PRReviewTable() {
  const cols = [
    { key: "team",    label: "Team" },
    { key: "open",    label: "Open PRs", align: "right", mono: true },
    { key: "first",   label: "1st response", align: "right", mono: true,
      render: v => <span style={{ color: v > 8 ? "var(--m-warn)" : "var(--m-fg-1)" }}>{v}h</span> },
    { key: "merge",   label: "Time to merge", align: "right", mono: true },
    { key: "stale",   label: "Stale > 3d", align: "right", mono: true,
      render: v => <span style={{ color: v > 0 ? "var(--m-warn)" : "var(--m-fg-2)" }}>{v}</span> },
    { key: "status",  label: "Status", render: v => <StateBadge state={v} /> },
  ];
  const rows = [
    { id: 1, team: "platform",     open: 8,  first: 2.4, merge: "11h", stale: 0, status: "live" },
    { id: 2, team: "growth",       open: 14, first: 9.1, merge: "31h", stale: 3, status: "stale" },
    { id: 3, team: "billing",      open: 6,  first: 4.2, merge: "18h", stale: 1, status: "live" },
    { id: 4, team: "search",       open: 9,  first: 1.8, merge: "9h",  stale: 0, status: "live" },
    { id: 5, team: "data-pipelines", open: 12, first: 14.6, merge: "44h", stale: 5, status: "stale" },
    { id: 6, team: "mobile",       open: 4,  first: 3.0, merge: "14h", stale: 0, status: "live" },
  ];
  return <MetralyTable columns={cols} rows={rows} selectedRows={[2]} livePulseRows={[1, 4]} />;
}

function DoraOverview() {
  const cells = [
    { label: "Deploy frequency",   value: "24/day", trend: "▲ 18%",  tone: "ok",   target: "Elite" },
    { label: "Lead time",          value: "41h",    trend: "▼ 6h",   tone: "ok",   target: "High" },
    { label: "Change failure rate", value: "4.2%",   trend: "▲ 0.8%", tone: "warn", target: "High" },
    { label: "MTTR",               value: "37m",    trend: "▼ 12m",  tone: "ok",   target: "Elite" },
  ];
  return (
    <div style={{ flex: 1, padding: 12, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, minHeight: 0 }}>
      {cells.map((c, i) => (
        <div key={i} style={{ background: "var(--m-bg-1)", border: "1px solid var(--m-line-faint)", borderRadius: 6, padding: "8px 10px", display: "flex", flexDirection: "column", gap: 2 }}>
          <div style={{ fontFamily: "var(--m-font-mono)", fontSize: 9, color: "var(--m-fg-3)", letterSpacing: "0.04em", textTransform: "uppercase" }}>{c.label}</div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 6 }}>
            <span style={{ fontFamily: "var(--m-font-mono)", fontSize: 18, color: "var(--m-fg-0)" }}>{c.value}</span>
            <span style={{ fontFamily: "var(--m-font-mono)", fontSize: 10, color: c.tone === "warn" ? "var(--m-warn)" : "var(--m-ok)" }}>{c.trend}</span>
          </div>
          <div style={{ fontFamily: "var(--m-font-mono)", fontSize: 9, color: "var(--m-cyan-500)" }}>· {c.target}</div>
        </div>
      ))}
    </div>
  );
}

function BlockedWork() {
  const items = [
    { stage: "Review",   sev: "warn",  title: "feat/cohorts-v2 · waiting 5d",      who: "growth · alex" },
    { stage: "QA",       sev: "warn",  title: "fix/upload-retries · 4d",            who: "platform · sami" },
    { stage: "Review",   sev: "error", title: "refactor/auth-tokens · 7d ↑",        who: "platform · jules" },
    { stage: "Deploy",   sev: "warn",  title: "perf/index-rebuild · 3d",            who: "search · noor" },
    { stage: "Triage",   sev: "info",  title: "chore/log-redaction · 3d",           who: "data · kai" },
  ];
  return (
    <div style={{ flex: 1, overflow: "auto", padding: 8, display: "flex", flexDirection: "column", gap: 4 }} className="m-scroll">
      {items.map((a, i) => (
        <div key={i} style={{
          display: "flex", alignItems: "center", gap: 8,
          padding: "6px 8px",
          background: i === 0 ? "var(--m-bg-3)" : "transparent",
          borderRadius: 4,
          borderLeft: `2px solid ${a.sev === "error" ? "var(--m-err)" : a.sev === "warn" ? "var(--m-warn)" : "var(--m-line)"}`,
        }}>
          <StatusDot state={a.sev === "error" ? "err" : a.sev === "warn" ? "stale" : "idle"} size={6} withPulse={i === 0} />
          <span style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
            <span style={{ fontSize: 11, color: "var(--m-fg-1)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{a.stage} · {a.title}</span>
            <span style={{ fontSize: 10, color: "var(--m-fg-3)", fontFamily: "var(--m-font-mono)" }}>{a.who}</span>
          </span>
        </div>
      ))}
    </div>
  );
}

// ─── DashboardEditor ────────────────────────────────────────────
function DashboardEditor({ accent = "cyan", showError = true, showStale = true, livePulse = true }) {
  const [activeNav, setActiveNav] = useStateDE("delivery");
  const [tab, setTab] = useStateDE("delivery");
  const [search, setSearch] = useStateDE("");
  const [time, setTime] = useStateDE("14d");
  const [editMode, setEditMode] = useStateDE(true);
  const [pickerOpen, setPickerOpen] = useStateDE(true);
  const [selected, setSelected] = useStateDE("cycle-time");
  const [draggingPicker, setDraggingPicker] = useStateDE(null);
  const [dropZoneState, setDropZoneState] = useStateDE("idle");
  const [draggingWidgetId, setDraggingWidgetId] = useStateDE(null);
  const [demoDragId, setDemoDragId] = useStateDE("blocked"); // visible "dragging" example for the brandbook
  const [widgets, setWidgets] = useStateDE([
    // Row 1 — DORA scalars
    { id: "deploy-freq", kind: "metric", title: "Deployment frequency", kindLabel: "dora/deploy-freq", value: "24 / day", delta: "▲ 18% vs −14d", deltaTone: "ok",
      spark: [4,6,5,7,8,6,9,11,10,12,14,13,15,14,12,16,18,17,15,19,21,18,22,24], pos: { col: 1, row: 1, w: 3, h: 1 } },
    { id: "lead-time",   kind: "metric", title: "Lead time for changes", kindLabel: "dora/lead-time",   value: "41h",     delta: "▼ 6h vs −14d",  deltaTone: "ok",
      spark: [62,60,58,56,55,54,52,50,49,48,47,46,45,44,44,43,43,42,42,42,41,41,41,41], pos: { col: 4, row: 1, w: 3, h: 1 } },
    { id: "cfr",         kind: "metric", title: "Change failure rate",  kindLabel: "dora/cfr",          value: "4.2%",    delta: "▲ 0.8% vs −14d", deltaTone: "warn",
      spark: [3.0,3.1,3.0,2.9,3.2,3.4,3.3,3.5,3.6,3.5,3.7,3.8,3.9,3.8,4.0,3.9,4.1,4.0,4.2,4.1,4.3,4.2,4.2,4.2], pos: { col: 7, row: 1, w: 3, h: 1 }, stale: showStale },
    { id: "ci-status",   kind: "metric", title: "CI failure rate",     kindLabel: "ci/fail",            state: "error", pos: { col: 10, row: 1, w: 3, h: 1 }, error: showError },

    // Row 2 — flow + DORA
    { id: "deploy-chart",  kind: "deployFreq", title: "Deploys / day · last 14d",  kindLabel: "dora/deploy-freq", pos: { col: 1, row: 2, w: 8, h: 2 } },
    { id: "dora-overview", kind: "dora",       title: "DORA overview",             kindLabel: "dora/overview",    pos: { col: 9, row: 2, w: 4, h: 2 }, unread: true },

    // Row 3 — review-centric
    { id: "cycle-time",  kind: "cycle",   title: "Cycle time breakdown", kindLabel: "flow/cycle",        pos: { col: 1, row: 4, w: 4, h: 2 } },
    { id: "review-lat",  kind: "metric",  title: "PR review latency · p50", kindLabel: "review/latency", value: "5.4h",  delta: "▼ 1.1h vs −14d", deltaTone: "ok",
      spark: [9,8.5,8,7.5,7.2,7,6.8,6.6,6.5,6.3,6.2,6,5.9,5.8,5.7,5.6,5.5,5.5,5.4,5.4,5.4,5.4,5.4,5.4], pos: { col: 5, row: 4, w: 4, h: 1 } },
    { id: "flaky",       kind: "metric",  title: "Flaky builds · 7d",    kindLabel: "ci/flaky",          value: "37",    delta: "▲ 9 vs −7d",     deltaTone: "warn",
      spark: [12,14,16,15,18,20,22,24,25,28,30,32,33,34,35,36,37,37,37,37,37,37,37,37], pos: { col: 9, row: 4, w: 4, h: 1 } },
    { id: "blocked",     kind: "blocked", title: "Blocked work",         kindLabel: "flow/blocked",      pos: { col: 5, row: 5, w: 4, h: 1 } },
    { id: "team-health", kind: "metric",  title: "Team delivery health", kindLabel: "team/health",       value: "78 / 100", delta: "▲ 4 vs −14d", deltaTone: "ok",
      spark: [70,71,71,72,72,73,73,74,74,74,75,75,76,76,76,77,77,77,77,78,78,78,78,78], pos: { col: 9, row: 5, w: 4, h: 1 } },

    // Row 4 — wide
    { id: "review-table", kind: "reviewTable", title: "PR review latency by team", kindLabel: "review/by-team", pos: { col: 1, row: 6, w: 12, h: 2 } },
  ]);

  const dragHover = draggingPicker != null;

  function widgetBody(w) {
    if (w.kind === "metric") {
      if (w.error) return null;
      return (
        <div style={{ flex: 1, padding: 12, display: "flex", flexDirection: "column", justifyContent: "space-between", minHeight: 0 }}>
          <div>
            <div style={{ fontFamily: "var(--m-font-mono)", fontSize: 26, color: "var(--m-fg-0)", lineHeight: 1, fontWeight: 500 }}>{w.value || "—"}</div>
            <div style={{ fontSize: 11, color: w.deltaTone === "warn" ? "var(--m-warn)" : w.deltaTone === "err" ? "var(--m-err)" : "var(--m-ok)", fontFamily: "var(--m-font-mono)", marginTop: 4 }}>{w.delta || ""}</div>
          </div>
          {w.spark && <Sparkline data={w.spark} width={240} height={42} color={w.deltaTone === "warn" ? "var(--m-warn)" : "var(--m-cyan-500)"} />}
        </div>
      );
    }
    if (w.kind === "deployFreq")  return <DeployFreqChart accent={accent} />;
    if (w.kind === "cycle")       return <CycleTimeBars />;
    if (w.kind === "dora")        return <DoraOverview />;
    if (w.kind === "blocked")     return <BlockedWork />;
    if (w.kind === "reviewTable") return <PRReviewTable />;
    return null;
  }

  function gridStyleFor(p) { return { gridColumn: `${p.col} / span ${p.w}`, gridRow: `${p.row} / span ${p.h}` }; }

  return (
    <div style={{ display: "flex", width: "100%", height: "100%", background: "var(--m-bg-0)", color: "var(--m-fg-1)", overflow: "hidden", borderRadius: "var(--m-r-4)" }}>
      <Sidebar active={activeNav} onNav={setActiveNav} />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        <Topbar
          title="Delivery · all teams"
          breadcrumbs={["Workspace", "Acme", "Dashboards", "Delivery"]}
          time={time} onTimeChange={setTime}
        />
        <div style={{ flex: 1, display: "flex", minHeight: 0 }}>
          <main className="m-scroll" style={{ flex: 1, overflow: "auto", padding: 16, display: "flex", flexDirection: "column", gap: 12, minWidth: 0 }}>
            <DashboardToolbar
              tabs={[
                { value: "delivery", label: "Delivery", count: 11 },
                { value: "dora",     label: "DORA",     count: 4 },
                { value: "flow",     label: "Flow",     count: 6 },
                { value: "review",   label: "Reviews",  count: 5 },
                { value: "ci",       label: "CI",       count: 3 },
              ]}
              activeTab={tab} onTabChange={setTab}
              search={search} onSearch={setSearch}
              syncState={livePulse ? "live" : "stale"}
              editMode={editMode} onToggleEdit={() => setEditMode(v => !v)}
              onAddWidget={() => setPickerOpen(true)}
            />

            {editMode && (
              <div style={{
                display: "flex", alignItems: "center", gap: 10, padding: "8px 12px",
                background: "var(--m-cyan-bg)", border: "1px dashed var(--m-cyan-500)",
                borderRadius: "var(--m-r-3)", fontFamily: "var(--m-font-mono)", fontSize: 11,
                color: "var(--m-cyan-500)", letterSpacing: "0.04em",
              }}>
                <PulseWave width={20} height={6} />
                <span style={{ textTransform: "uppercase" }}>Edit mode</span>
                <span style={{ color: "var(--m-fg-2)", textTransform: "none" }}>· Drag widgets to rearrange (grip dots only) · Drag corners to resize · Drag from library to add</span>
                <span style={{ flex: 1 }} />
                <button className="m-focusable" onClick={() => setEditMode(false)} style={{ ...ghostBtn, height: 24, padding: "0 8px" }}><Icon name="check" size={11} /> Done</button>
              </div>
            )}

            <div
              onDragOver={(e) => { e.preventDefault(); setDropZoneState("active"); }}
              onDragLeave={() => setDropZoneState("idle")}
              onDrop={(e) => {
                e.preventDefault();
                const id = e.dataTransfer.getData("text/plain");
                setDropZoneState("idle"); setDraggingPicker(null);
                if (id) {
                  setWidgets(ws => [...ws, { id: `${id}-${Date.now()}`, kind: "metric",
                    title: id.replace(/-/g, " "), kindLabel: id, value: "—", delta: "",
                    spark: [10,12,11,13,15,14,16], pos: { col: 1, row: 99, w: 3, h: 1 } }]);
                }
              }}
              style={{ display: "grid", gridTemplateColumns: "repeat(12, 1fr)", gridAutoRows: "minmax(150px, auto)", gap: 12, position: "relative", paddingBottom: 12 }}
            >
              {widgets.map(w => {
                const isSelected = selected === w.id && editMode;
                const visualDragging = draggingWidgetId === w.id || (editMode && demoDragId === w.id);
                return (
                  <div key={w.id} style={gridStyleFor(w.pos)}
                    draggable={editMode}
                    onDragStart={(e) => {
                      setDraggingWidgetId(w.id); setDemoDragId(null);
                      e.dataTransfer.effectAllowed = "move";
                      // tiny transparent drag image so the source widget itself stays visible
                      // and renders the proper "dragging" treatment.
                      const img = new Image();
                      img.src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==";
                      try { e.dataTransfer.setDragImage(img, 0, 0); } catch (_) {}
                    }}
                    onDragEnd={() => setDraggingWidgetId(null)}
                  >
                    <WidgetShell
                      title={w.title} kind={w.kindLabel}
                      selected={isSelected}
                      isStale={w.stale} isError={w.error}
                      unread={w.unread}
                      dragging={visualDragging}
                      height="100%"
                      accent={accent}
                      onSelect={() => editMode && (setSelected(w.id), setDemoDragId(null))}
                      footer={
                        w.kind === "deployFreq" || w.kind === "cycle" || w.kind === "reviewTable"
                          ? <><span>updated 12s ago</span><span>{livePulse && <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}><PulseWave width={20} height={6} /> live</span>}</span></>
                          : null
                      }
                    >
                      {widgetBody(w)}
                    </WidgetShell>
                  </div>
                );
              })}

              {editMode && (
                <div style={{ gridColumn: "1 / span 12" }}>
                  <DashboardDropZone
                    state={dragHover ? (dropZoneState === "active" ? "active" : "hover") : "idle"}
                    label="Drag a widget here · or click + Add widget"
                    accent={accent}
                  />
                </div>
              )}
            </div>
          </main>

          {pickerOpen && editMode && (
            <WidgetPicker
              draggingId={draggingPicker}
              onDragStart={(id) => setDraggingPicker(id)}
              onDragEnd={() => { setDraggingPicker(null); setDropZoneState("idle"); }}
              onPick={(id) => {
                setWidgets(ws => [...ws, { id: `${id}-${Date.now()}`, kind: "metric",
                  title: id.replace(/-/g, " "), kindLabel: id, value: "—", delta: "",
                  spark: [10,12,11,13,15,14,16], pos: { col: 1, row: 99, w: 3, h: 1 } }]);
              }}
              onClose={() => setPickerOpen(false)}
            />
          )}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { DashboardEditor });
