// form-controls.jsx — Metraly form components
// Covers: MetralyCheckbox, MetralyRadio, MetralySwitch, MetralySelect,
// MetralyTabs, StateBadge.
// Rules:
//  • No vertical hover jump (border/bg only).
//  • focus-visible ring is always visible & accessible.
//  • Disabled = visually clear + non-interactive (pointer-events:none, 0.45 opacity, no focus).
//  • Selected ⇒ cyan ring + optional pulse-wave (semantic).

const { useState: useStateF, useId } = React;

// ─── MetralyCheckbox ────────────────────────────────────────────
function MetralyCheckbox({ checked = false, indeterminate = false, disabled = false, loading = false, error = false, onChange, label, hint }) {
  const id = useId();
  const state = disabled ? "disabled" : loading ? "loading" : error ? "error" : checked || indeterminate ? "checked" : "default";
  return (
    <label htmlFor={id} className="m-cb-row" data-state={state} style={{
      display: "inline-flex", alignItems: "flex-start", gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      pointerEvents: disabled ? "none" : "auto",
    }}>
      <span className="m-cb m-focusable" tabIndex={disabled ? -1 : 0}
        onClick={(e) => { if (!disabled && !loading) { onChange?.(!checked); } }}
        onKeyDown={(e) => { if (e.key === " " && !disabled && !loading) { e.preventDefault(); onChange?.(!checked); } }}
        role="checkbox" aria-checked={indeterminate ? "mixed" : checked} aria-disabled={disabled}
        style={{
          width: 16, height: 16, borderRadius: 4,
          border: `1px solid ${error ? "var(--m-err)" : checked || indeterminate ? "var(--m-cyan-500)" : "var(--m-line-strong)"}`,
          background: checked || indeterminate ? "var(--m-cyan-500)" : "var(--m-bg-1)",
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          transition: "background var(--m-dur-2) var(--m-ease), border-color var(--m-dur-2) var(--m-ease)",
          flex: "0 0 auto", marginTop: 1,
          boxShadow: error ? "0 0 0 3px var(--m-err-bg)" : "none",
        }}>
        {loading ? (
          <span className="m-spin" style={{ width: 9, height: 9, border: "1.4px solid var(--m-cyan-500)", borderTopColor: "transparent", borderRadius: "50%", animation: "m-spin 0.7s linear infinite" }} />
        ) : indeterminate ? (
          <svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 5 H8" stroke="var(--m-bg-0)" strokeWidth="1.6" strokeLinecap="round" /></svg>
        ) : checked ? (
          <svg width="10" height="10" viewBox="0 0 10 10"><path d="M2 5 L4 7 L8 3" stroke="var(--m-bg-0)" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
        ) : null}
      </span>
      {(label || hint) && (
        <span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}>
          {label && <span style={{ fontSize: "var(--m-fs-12)", color: "var(--m-fg-1)", lineHeight: 1.3 }}>{label}</span>}
          {hint && <span style={{ fontSize: "var(--m-fs-10)", color: error ? "var(--m-err)" : "var(--m-fg-3)" }}>{hint}</span>}
        </span>
      )}
    </label>
  );
}

// ─── MetralyRadio ───────────────────────────────────────────────
function MetralyRadio({ checked = false, disabled = false, error = false, onChange, label, hint, name }) {
  return (
    <label className="m-radio-row" style={{
      display: "inline-flex", alignItems: "flex-start", gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      pointerEvents: disabled ? "none" : "auto",
    }}>
      <span className="m-radio m-focusable" tabIndex={disabled ? -1 : 0}
        role="radio" aria-checked={checked} aria-disabled={disabled}
        onClick={() => !disabled && onChange?.(true)}
        onKeyDown={(e) => { if (e.key === " ") { e.preventDefault(); onChange?.(true); } }}
        style={{
          width: 16, height: 16, borderRadius: "50%",
          border: `1px solid ${error ? "var(--m-err)" : checked ? "var(--m-cyan-500)" : "var(--m-line-strong)"}`,
          background: "var(--m-bg-1)",
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          transition: "border-color var(--m-dur-2) var(--m-ease)",
          flex: "0 0 auto", marginTop: 1,
        }}>
        {checked && <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--m-cyan-500)", boxShadow: "0 0 6px -1px var(--m-cyan-glow)" }} />}
      </span>
      {(label || hint) && (
        <span style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {label && <span style={{ fontSize: "var(--m-fs-12)", color: "var(--m-fg-1)" }}>{label}</span>}
          {hint && <span style={{ fontSize: "var(--m-fs-10)", color: "var(--m-fg-3)" }}>{hint}</span>}
        </span>
      )}
    </label>
  );
}

// ─── MetralySwitch ──────────────────────────────────────────────
function MetralySwitch({ checked = false, disabled = false, loading = false, onChange, label, accent = "cyan" }) {
  const tone = accent === "purple" ? "var(--m-purple-500)" : "var(--m-cyan-500)";
  const glow = accent === "purple" ? "var(--m-purple-glow)" : "var(--m-cyan-glow)";
  return (
    <label style={{ display: "inline-flex", alignItems: "center", gap: 10, cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.45 : 1, pointerEvents: disabled ? "none" : "auto" }}>
      <span className="m-focusable" tabIndex={disabled ? -1 : 0}
        role="switch" aria-checked={checked} aria-disabled={disabled}
        onClick={() => !disabled && !loading && onChange?.(!checked)}
        onKeyDown={(e) => { if (e.key === " ") { e.preventDefault(); !loading && onChange?.(!checked); } }}
        style={{
          width: 30, height: 16, borderRadius: 999,
          background: checked ? tone : "var(--m-bg-3)",
          border: `1px solid ${checked ? tone : "var(--m-line-strong)"}`,
          position: "relative", display: "inline-block", flex: "0 0 auto",
          transition: "background var(--m-dur-2) var(--m-ease), border-color var(--m-dur-2) var(--m-ease)",
          boxShadow: checked ? `0 0 8px -2px ${glow}` : "none",
        }}>
        <span style={{
          position: "absolute", top: 1, left: checked ? 15 : 1,
          width: 12, height: 12, borderRadius: "50%",
          background: checked ? "var(--m-bg-0)" : "var(--m-fg-2)",
          transition: "left var(--m-dur-2) var(--m-ease)",
        }}>
          {loading && <span className="m-spin" style={{ position: "absolute", inset: 1, border: "1.2px solid var(--m-cyan-500)", borderTopColor: "transparent", borderRadius: "50%", animation: "m-spin 0.7s linear infinite" }} />}
        </span>
      </span>
      {label && <span style={{ fontSize: "var(--m-fs-12)", color: "var(--m-fg-1)" }}>{label}</span>}
    </label>
  );
}

// ─── MetralySelect ──────────────────────────────────────────────
function MetralySelect({ value, options = [], onChange, placeholder = "Select…", disabled = false, loading = false, error = false, width = 200, open: openProp, onOpenChange, hint }) {
  const [openS, setOpenS] = useStateF(false);
  const open = openProp ?? openS;
  const setOpen = onOpenChange ?? setOpenS;
  const selected = options.find(o => o.value === value);
  return (
    <div style={{ position: "relative", width, opacity: disabled ? 0.45 : 1, pointerEvents: disabled ? "none" : "auto" }}>
      <button className="m-focusable" disabled={disabled || loading}
        onClick={() => setOpen(!open)}
        aria-haspopup="listbox" aria-expanded={open} aria-disabled={disabled}
        style={{
          width: "100%", height: "var(--m-control-h)",
          padding: "0 var(--m-pad-x)",
          background: "var(--m-bg-2)",
          color: selected ? "var(--m-fg-1)" : "var(--m-fg-3)",
          border: `1px solid ${error ? "var(--m-err)" : open ? "var(--m-cyan-500)" : "var(--m-line)"}`,
          borderRadius: "var(--m-r-2)",
          fontSize: "var(--m-fs-12)", fontFamily: "var(--m-font-ui)",
          display: "inline-flex", alignItems: "center", justifyContent: "space-between", gap: 8,
          cursor: disabled ? "not-allowed" : "pointer", textAlign: "left",
          transition: "border-color var(--m-dur-2), background var(--m-dur-2)",
          boxShadow: error ? "0 0 0 3px var(--m-err-bg)" : open ? "var(--m-glow-selected)" : "none",
        }}
        onMouseEnter={(e) => { if (!disabled && !open && !error) e.currentTarget.style.borderColor = "var(--m-line-strong)"; }}
        onMouseLeave={(e) => { if (!open && !error) e.currentTarget.style.borderColor = "var(--m-line)"; }}
      >
        <span style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {loading && <span className="m-spin" style={{ width: 10, height: 10, border: "1.4px solid var(--m-cyan-500)", borderTopColor: "transparent", borderRadius: "50%", animation: "m-spin 0.7s linear infinite" }} />}
          {selected ? selected.label : placeholder}
        </span>
        <Icon name="chevron" size={12} />
      </button>
      {open && !disabled && (
        <div role="listbox" className="m-scroll" style={{
          position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0,
          background: "var(--m-bg-2)",
          border: "1px solid var(--m-line)",
          borderRadius: "var(--m-r-2)",
          boxShadow: "0 12px 32px -8px rgba(0,0,0,0.5), 0 0 0 1px var(--m-line-faint)",
          padding: 4, zIndex: 30, maxHeight: 240, overflow: "auto",
        }}>
          {options.length === 0 ? (
            <div style={{ padding: "12px 8px", color: "var(--m-fg-3)", fontSize: "var(--m-fs-11)", textAlign: "center", fontStyle: "italic" }}>No options</div>
          ) : options.map(opt => (
            <button key={opt.value} role="option" aria-selected={opt.value === value} disabled={opt.disabled}
              onClick={() => { onChange?.(opt.value); setOpen(false); }}
              style={{
                width: "100%", textAlign: "left", padding: "6px 8px",
                background: opt.value === value ? "var(--m-cyan-bg)" : "transparent",
                border: "none", color: opt.disabled ? "var(--m-fg-4)" : "var(--m-fg-1)",
                fontSize: "var(--m-fs-12)", fontFamily: "var(--m-font-ui)",
                borderRadius: "var(--m-r-1)", cursor: opt.disabled ? "not-allowed" : "pointer",
                display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8,
                transition: "background var(--m-dur-1)",
              }}
              onMouseEnter={(e) => { if (!opt.disabled && opt.value !== value) e.currentTarget.style.background = "var(--m-bg-3)"; }}
              onMouseLeave={(e) => { if (opt.value !== value) e.currentTarget.style.background = "transparent"; }}
            >
              <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                {opt.icon && <Icon name={opt.icon} size={12} />}
                {opt.label}
              </span>
              {opt.value === value && <Icon name="check" size={11} />}
            </button>
          ))}
        </div>
      )}
      {hint && <div style={{ fontSize: "var(--m-fs-10)", color: error ? "var(--m-err)" : "var(--m-fg-3)", marginTop: 4 }}>{hint}</div>}
    </div>
  );
}

// ─── MetralyTabs ────────────────────────────────────────────────
// Underline tabs. Selected tab gets a cyan underline + optional pulse-wave.
function MetralyTabs({ tabs = [], value, onChange, livePulse = false }) {
  return (
    <div role="tablist" style={{ display: "flex", gap: 4, borderBottom: "1px solid var(--m-line)" }}>
      {tabs.map(tab => {
        const selected = tab.value === value;
        const disabled = tab.disabled;
        return (
          <button key={tab.value} role="tab" aria-selected={selected} aria-disabled={disabled} disabled={disabled}
            className="m-focusable"
            onClick={() => !disabled && onChange?.(tab.value)}
            style={{
              position: "relative", border: "none", background: "transparent",
              padding: "8px 12px",
              fontSize: "var(--m-fs-12)", fontFamily: "var(--m-font-ui)",
              color: disabled ? "var(--m-fg-4)" : selected ? "var(--m-fg-0)" : "var(--m-fg-2)",
              cursor: disabled ? "not-allowed" : "pointer",
              display: "inline-flex", alignItems: "center", gap: 6,
              transition: "color var(--m-dur-2)",
              opacity: disabled ? 0.5 : 1,
            }}
            onMouseEnter={(e) => { if (!disabled && !selected) e.currentTarget.style.color = "var(--m-fg-1)"; }}
            onMouseLeave={(e) => { if (!disabled && !selected) e.currentTarget.style.color = "var(--m-fg-2)"; }}
          >
            {tab.icon && <Icon name={tab.icon} size={12} />}
            {tab.label}
            {tab.count != null && (
              <span style={{
                fontFamily: "var(--m-font-mono)", fontSize: "var(--m-fs-10)",
                color: selected ? "var(--m-cyan-500)" : "var(--m-fg-3)",
                background: selected ? "var(--m-cyan-bg)" : "var(--m-bg-3)",
                padding: "1px 6px", borderRadius: 999,
                minWidth: 18, textAlign: "center",
              }}>{tab.count}</span>
            )}
            {selected && (
              <span style={{ position: "absolute", left: 8, right: 8, bottom: -1, height: 2, background: "var(--m-cyan-500)", borderRadius: 1, boxShadow: "0 0 8px -1px var(--m-cyan-glow)" }} />
            )}
            {selected && livePulse && (
              <span style={{ position: "absolute", right: -2, top: 6 }}><PulseWave width={14} height={6} /></span>
            )}
          </button>
        );
      })}
    </div>
  );
}

// ─── StateBadge ─────────────────────────────────────────────────
// Semantic chip: live/stale/error/disabled/new/info.
function StateBadge({ state = "ok", label, icon, withPulse }) {
  const tones = {
    live:   { fg: "var(--m-ok)",     bg: "var(--m-ok-bg)",     dot: "live",   label: "Live" },
    ok:     { fg: "var(--m-ok)",     bg: "var(--m-ok-bg)",     dot: "ok",     label: "OK" },
    stale:  { fg: "var(--m-warn)",   bg: "var(--m-warn-bg)",   dot: "stale",  label: "Stale" },
    error:  { fg: "var(--m-err)",    bg: "var(--m-err-bg)",    dot: "err",    label: "Error" },
    new:    { fg: "var(--m-cyan-500)", bg: "var(--m-cyan-bg)", dot: "new",    label: "New" },
    info:   { fg: "var(--m-fg-1)",   bg: "var(--m-bg-3)",      dot: "idle",   label: "Info" },
    purple: { fg: "var(--m-purple-500)", bg: "var(--m-purple-bg)", dot: "idle", label: "Beta" },
    disabled: { fg: "var(--m-fg-4)", bg: "var(--m-bg-2)", dot: "idle", label: "—" },
  };
  const t = tones[state] || tones.info;
  const pulse = withPulse ?? (state === "live" || state === "new");
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      padding: "2px 8px 2px 6px",
      background: t.bg, color: t.fg,
      borderRadius: 999,
      fontFamily: "var(--m-font-mono)", fontSize: "var(--m-fs-10)",
      letterSpacing: "0.04em", textTransform: "uppercase",
      border: state === "disabled" ? "1px dashed var(--m-line)" : `1px solid ${t.fg.replace(")", " / 0.18)")}`,
      lineHeight: 1.2,
    }}>
      <StatusDot state={t.dot} size={6} withPulse={pulse} />
      {label || t.label}
    </span>
  );
}

// ─── Spinner keyframes ──────────────────────────────────────────
if (typeof document !== "undefined" && !document.getElementById("m-spin-css")) {
  const s = document.createElement("style");
  s.id = "m-spin-css";
  s.textContent = "@keyframes m-spin{to{transform:rotate(360deg)}}";
  document.head.appendChild(s);
}

Object.assign(window, { MetralyCheckbox, MetralyRadio, MetralySwitch, MetralySelect, MetralyTabs, StateBadge });
