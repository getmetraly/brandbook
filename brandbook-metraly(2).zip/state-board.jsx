// state-board.jsx — Component state board.
// One artboard per component, each showing all relevant states in a grid.

const { useState: useStateSB } = React;

function Cell({ label, children, span = 1 }) {
  return (
    <div style={{ gridColumn: `span ${span}`, display: "flex", flexDirection: "column", gap: 8, padding: 12, background: "var(--m-bg-1)", border: "1px solid var(--m-line-faint)", borderRadius: "var(--m-r-3)" }}>
      <div style={{
        fontFamily: "var(--m-font-mono)", fontSize: 9, letterSpacing: "0.06em",
        textTransform: "uppercase", color: "var(--m-fg-3)",
      }}>{label}</div>
      <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: 12, minHeight: 32 }}>{children}</div>
    </div>
  );
}

function Grid({ cols = 3, children }) {
  return <div style={{ display: "grid", gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`, gap: 10 }}>{children}</div>;
}

function BoardTitle({ name, slug, hardening }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10, paddingBottom: 8, borderBottom: "1px solid var(--m-line-faint)" }}>
      <div style={{
        width: 20, height: 20, borderRadius: 4,
        background: "var(--m-cyan-bg)", color: "var(--m-cyan-500)",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        border: "1px solid var(--m-cyan-500)",
        fontFamily: "var(--m-font-mono)", fontSize: 11, fontWeight: 600,
      }}>M</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: "var(--m-fs-13)", color: "var(--m-fg-0)", fontWeight: 500 }}>{name}</div>
        <div style={{ fontSize: "var(--m-fs-9)", color: "var(--m-fg-3)", fontFamily: "var(--m-font-mono)" }}>{slug}</div>
      </div>
      <StateBadge state={hardening === "ready" ? "ok" : hardening === "preview" ? "purple" : "stale"} label={hardening === "ready" ? "Ready" : hardening === "preview" ? "Preview-only" : "Hardening"} />
    </div>
  );
}

// ─── Boards ─────────────────────────────────────────────────────
function CheckboxBoard() {
  const [a, setA] = useStateSB(true), [b, setB] = useStateSB(false), [c, setC] = useStateSB(false);
  return (
    <div>
      <BoardTitle name="MetralyCheckbox" slug="metraly/checkbox" hardening="ready" />
      <Grid cols={3}>
        <Cell label="default"><MetralyCheckbox checked={false} label="Stream metrics" /></Cell>
        <Cell label="hover">
          <span style={{ filter: "brightness(1.1)" }}><MetralyCheckbox checked={false} label="Auto-retry" /></span>
        </Cell>
        <Cell label="focus-visible"><MetralyCheckbox checked={false} label="Always-on focus" /><span style={{position:"absolute",left:-9999}}>see ring on tab</span></Cell>
        <Cell label="checked"><MetralyCheckbox checked={true} label="Telemetry on" /></Cell>
        <Cell label="indeterminate"><MetralyCheckbox indeterminate label="Some sources" /></Cell>
        <Cell label="disabled"><MetralyCheckbox checked={true} disabled label="Locked policy" /></Cell>
        <Cell label="loading"><MetralyCheckbox loading checked label="Saving…" /></Cell>
        <Cell label="error"><MetralyCheckbox error checked={false} label="Token expired" hint="Re-authenticate to continue" /></Cell>
        <Cell label="interactive"><MetralyCheckbox checked={a} onChange={setA} label="Try me" hint="Space or click" /></Cell>
      </Grid>
    </div>
  );
}

function RadioBoard() {
  const [v, setV] = useStateSB("p99");
  return (
    <div>
      <BoardTitle name="MetralyRadio" slug="metraly/radio" hardening="ready" />
      <Grid cols={3}>
        <Cell label="default"><MetralyRadio label="p50" /></Cell>
        <Cell label="checked"><MetralyRadio checked label="p99" /></Cell>
        <Cell label="focus-visible"><MetralyRadio label="Tab to focus" /></Cell>
        <Cell label="disabled"><MetralyRadio disabled label="median (locked)" /></Cell>
        <Cell label="error"><MetralyRadio error label="Invalid metric" hint="Choose a supported quantile" /></Cell>
        <Cell label="group" span={3}>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            {["p50","p90","p99","max"].map(k => (
              <MetralyRadio key={k} checked={v===k} onChange={() => setV(k)} label={k.toUpperCase()} />
            ))}
          </div>
        </Cell>
      </Grid>
    </div>
  );
}

function SwitchBoard() {
  const [a, setA] = useStateSB(true);
  return (
    <div>
      <BoardTitle name="MetralySwitch" slug="metraly/switch" hardening="ready" />
      <Grid cols={3}>
        <Cell label="off"><MetralySwitch checked={false} label="Live tail" /></Cell>
        <Cell label="on"><MetralySwitch checked={true} label="Live tail" /></Cell>
        <Cell label="loading"><MetralySwitch loading checked={true} label="Applying…" /></Cell>
        <Cell label="disabled (off)"><MetralySwitch disabled checked={false} label="Read-only" /></Cell>
        <Cell label="disabled (on)"><MetralySwitch disabled checked={true} label="Locked" /></Cell>
        <Cell label="purple accent"><MetralySwitch checked={true} accent="purple" label="Beta channel" /></Cell>
        <Cell label="interactive" span={3}><MetralySwitch checked={a} onChange={setA} label={`Toggleable: ${a ? "on" : "off"}`} /></Cell>
      </Grid>
    </div>
  );
}

function SelectBoard() {
  const opts = [
    { value: "5m",  label: "Last 5 minutes",  icon: "metric" },
    { value: "1h",  label: "Last 1 hour",     icon: "metric" },
    { value: "24h", label: "Last 24 hours",   icon: "metric" },
    { value: "7d",  label: "Last 7 days",     icon: "metric" },
    { value: "custom", label: "Custom range…", disabled: true },
  ];
  const [v, setV] = useStateSB("1h");
  return (
    <div>
      <BoardTitle name="MetralySelect" slug="metraly/select" hardening="harden" />
      <Grid cols={2}>
        <Cell label="default"><MetralySelect options={opts} placeholder="Select range…" /></Cell>
        <Cell label="value selected"><MetralySelect options={opts} value="24h" /></Cell>
        <Cell label="open · selected"><MetralySelect options={opts} value="1h" open onOpenChange={() => {}} /></Cell>
        <Cell label="loading"><MetralySelect options={opts} value="1h" loading /></Cell>
        <Cell label="error"><MetralySelect options={opts} error hint="Range exceeds retention" /></Cell>
        <Cell label="disabled"><MetralySelect options={opts} value="1h" disabled /></Cell>
        <Cell label="empty"><MetralySelect options={[]} placeholder="No sources" open onOpenChange={() => {}} /></Cell>
        <Cell label="interactive"><MetralySelect options={opts} value={v} onChange={setV} /></Cell>
      </Grid>
    </div>
  );
}

function TabsBoard() {
  const [v, setV] = useStateSB("metrics");
  const tabs = [
    { value: "dora",    label: "DORA",    icon: "lightning", count: 4 },
    { value: "flow",    label: "Flow",    icon: "chart", count: 6 },
    { value: "review",  label: "Reviews", icon: "log", count: 5 },
    { value: "ci",      label: "CI",      icon: "refresh", count: 3 },
    { value: "team",    label: "Teams",   icon: "user", disabled: true },
  ];
  return (
    <div>
      <BoardTitle name="MetralyTabs" slug="metraly/tabs" hardening="harden" />
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <Cell label="default + counts" span={3}><div style={{ width: "100%" }}><MetralyTabs tabs={tabs} value={v} onChange={setV} /></div></Cell>
        <Cell label="selected with live pulse" span={3}><div style={{ width: "100%" }}><MetralyTabs tabs={tabs} value="metrics" livePulse /></div></Cell>
        <Cell label="disabled tab" span={3}><div style={{ width: "100%" }}><MetralyTabs tabs={tabs} value="deploys" /></div></Cell>
      </div>
    </div>
  );
}

function StateBadgeBoard() {
  return (
    <div>
      <BoardTitle name="StateBadge" slug="metraly/state-badge" hardening="ready" />
      <Grid cols={3}>
        <Cell label="live"><StateBadge state="live" /></Cell>
        <Cell label="ok"><StateBadge state="ok" label="Healthy" /></Cell>
        <Cell label="stale"><StateBadge state="stale" label="Stale 4m" /></Cell>
        <Cell label="error"><StateBadge state="error" label="Disconnected" /></Cell>
        <Cell label="new / unread"><StateBadge state="new" label="3 new" /></Cell>
        <Cell label="info"><StateBadge state="info" label="Cached" /></Cell>
        <Cell label="purple · beta"><StateBadge state="purple" label="Beta" /></Cell>
        <Cell label="disabled"><StateBadge state="disabled" label="N/A" /></Cell>
        <Cell label="pulse off (reduced motion)"><StateBadge state="ok" label="Healthy" withPulse={false} /></Cell>
      </Grid>
    </div>
  );
}

function WidgetPickerBoard() {
  return (
    <div>
      <BoardTitle name="WidgetPickerCard" slug="metraly/widget-picker-card" hardening="visual-ready" />
      <Grid cols={2}>
        <Cell label="default"><div style={{width:240}}><WidgetPickerCard icon="metric" title="Metric card" kind="metric/scalar" description="Single KPI with delta and sparkline." /></div></Cell>
        <Cell label="selected"><div style={{width:240}}><WidgetPickerCard icon="chart" title="Time-series chart" kind="chart/line" state="selected" description="Multi-series line, p50/p99 overlay." /></div></Cell>
        <Cell label="new"><div style={{width:240}}><WidgetPickerCard icon="lightning" title="Flaky builds · 7d" kind="ci/flaky" state="new" description="Tests retried-then-passed." /></div></Cell>
        <Cell label="disabled"><div style={{width:240}}><WidgetPickerCard icon="user" title="WIP per engineer" kind="flow/wip" state="disabled" description="Source not connected." /></div></Cell>
        <Cell label="loading"><div style={{width:240}}><WidgetPickerCard icon="server" title="Server pool" kind="metric/cluster" state="loading" /></div></Cell>
        <Cell label="dragging"><div style={{width:240}}><WidgetPickerCard icon="chart" title="Time-series chart" kind="chart/line" dragging /></div></Cell>
      </Grid>
    </div>
  );
}

function MetricCard({ label, value, delta, deltaTone = "ok", spark, state }) {
  const kindLabel = {
    "p99 latency": "metric/latency",
    "Requests / s": "metric/rps",
    "Error rate": "metric/error",
    "CPU saturation": "metric/cpu",
    "Disk IO": "metric/disk",
    "Lead time for changes": "dora/lead-time",
    "Deployment frequency": "dora/deploy-freq",
    "MTTR": "dora/mttr",
    "Change failure rate": "dora/cfr",
    "CI failure rate": "ci/fail",
  }[label] || "metric/scalar";
  return (
    <WidgetShell title={label} kind={kindLabel} height={150} state={state}
      isStale={state === "stale"} isError={state === "error"} isLoading={state === "loading"} isEmpty={state === "empty"}>
      <div style={{ flex: 1, padding: 14, display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontFamily: "var(--m-font-mono)", fontSize: 24, color: "var(--m-fg-0)", lineHeight: 1, fontWeight: 500 }}>{value}</div>
          <div style={{ fontSize: 11, color: deltaTone === "err" ? "var(--m-err)" : deltaTone === "warn" ? "var(--m-warn)" : "var(--m-ok)", fontFamily: "var(--m-font-mono)", marginTop: 4 }}>{delta}</div>
        </div>
        {spark && <Sparkline data={spark} width={220} height={36} />}
      </div>
    </WidgetShell>
  );
}

function WidgetShellBoard() {
  const spark = [12,14,11,13,16,15,18,17,20,19,22,21,24,23,26,28,27,29,30,32];
  return (
    <div>
      <BoardTitle name="WidgetShell" slug="metraly/widget-shell" hardening="visual-ready" />
      <Grid cols={2}>
        <Cell label="default · live"><div style={{width:280}}><MetricCard label="Deployment frequency" value="24 / day" delta="▲ 18% vs −14d" spark={spark} /></div></Cell>
        <Cell label="selected"><div style={{width:280}}><WidgetShell title="Lead time for changes" kind="dora/lead-time" selected height={150}>
          <div style={{ padding: 14 }}>
            <div style={{ fontFamily: "var(--m-font-mono)", fontSize: 24, color: "var(--m-fg-0)" }}>41h</div>
            <div style={{ fontSize: 11, color: "var(--m-ok)", fontFamily: "var(--m-font-mono)" }}>▼ 6h vs −14d</div>
          </div>
        </WidgetShell></div></Cell>
        <Cell label="dragging"><div style={{width:280}}><MetricCard label="Lead time for changes" value="41h" delta="▼ 6h vs −14d" deltaTone="ok" spark={spark.slice().reverse()} /></div></Cell>
        <Cell label="resizing"><div style={{width:280}}><WidgetShell title="Change failure rate" kind="dora/cfr" selected resizing height={150}>
          <div style={{ padding: 14 }}>
            <div style={{ fontFamily: "var(--m-font-mono)", fontSize: 24, color: "var(--m-fg-0)" }}>4.2%</div>
            <div style={{ fontSize: 11, color: "var(--m-warn)", fontFamily: "var(--m-font-mono)" }}>▲ 0.8% vs −14d</div>
          </div>
        </WidgetShell></div></Cell>
        <Cell label="loading"><div style={{width:280}}><MetricCard label="MTTR" value="—" delta="" state="loading" /></div></Cell>
        <Cell label="empty"><div style={{width:280}}><MetricCard label="CI failure rate" value="—" delta="" state="empty" /></div></Cell>
        <Cell label="stale"><div style={{width:280}}><MetricCard label="Change failure rate" value="4.2%" delta="last 4m ago" deltaTone="warn" state="stale" spark={spark} /></div></Cell>
        <Cell label="error · disconnected"><div style={{width:280}}><MetricCard label="Flaky builds" value="—" delta="" state="error" /></div></Cell>
        <Cell label="unread / new" span={2}><div style={{width:280}}><WidgetShell title="Blocked work" kind="flow/blocked" unread height={150}>
          <div style={{ padding: 14, display: "flex", flexDirection: "column", gap: 8 }}>
            <div style={{ fontFamily: "var(--m-font-mono)", fontSize: 11 }}>3 new blocked issues</div>
            <div style={{ fontFamily: "var(--m-font-mono)", fontSize: 10, color: "var(--m-fg-3)" }}>↳ feat/cohorts-v2 · review 5d</div>
            <div style={{ fontFamily: "var(--m-font-mono)", fontSize: 10, color: "var(--m-fg-3)" }}>↳ refactor/auth-tokens · blocked</div>
          </div>
        </WidgetShell></div></Cell>
      </Grid>
    </div>
  );
}

function ToolbarBoard() {
  const [tab, setTab] = React.useState("dora");
  return (
    <div>
      <BoardTitle name="DashboardToolbar" slug="metraly/dashboard-toolbar" hardening="visual-ready" />
      <Grid cols={1}>
        <Cell label="two-row layout (tabs / search-sync-edit-add)" span={1}>
          <div style={{ width: "100%", border: "1px solid var(--m-line-faint)", borderRadius: 6 }}>
            <DashboardToolbar
              tabs={[
                { value: "dora", label: "DORA", count: 4 },
                { value: "flow", label: "Flow", count: 6 },
                { value: "review", label: "Reviews", count: 5 },
                { value: "ci", label: "CI", count: 3 },
              ]}
              activeTab={tab} onTabChange={setTab}
              search="" onSearch={() => {}}
              syncState="live"
              onAddWidget={() => {}}
              onToggleEdit={() => {}}
              editMode={true}
            />
          </div>
        </Cell>
      </Grid>
    </div>
  );
}

function TableBoard() {
  const cols = [
    { key: "service", label: "Service" },
    { key: "p99", label: "p99", align: "right", mono: true },
    { key: "rps", label: "RPS", align: "right", mono: true },
    { key: "err", label: "Err %", align: "right", mono: true, render: v => <span style={{ color: v > 1 ? "var(--m-err)" : "var(--m-fg-1)" }}>{v.toFixed(2)}</span> },
    { key: "status", label: "Status", render: v => <StateBadge state={v} /> },
  ];
  const rows = [
    { id: 1, service: "api-gateway",  p99: "184 ms", rps: "3 482", err: 0.18, status: "live" },
    { id: 2, service: "auth-service", p99: "92 ms",  rps: "1 204", err: 0.04, status: "live" },
    { id: 3, service: "billing",      p99: "612 ms", rps: "238",   err: 1.42, status: "stale" },
    { id: 4, service: "search-index", p99: "47 ms",  rps: "5 612", err: 0.02, status: "live" },
    { id: 5, service: "worker-pool",  p99: "—",      rps: "—",     err: 0,    status: "error" },
  ];
  return (
    <div>
      <BoardTitle name="MetralyTable" slug="metraly/table" hardening="harden" />
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <Cell label="default with selected row + unread" span={3}>
          <div style={{ width: "100%", border: "1px solid var(--m-line)", borderRadius: "var(--m-r-3)", overflow: "hidden", background: "var(--m-bg-2)" }}>
            <MetralyTable columns={cols} rows={rows} selectedRows={[2]} livePulseRows={[1, 3]} />
          </div>
        </Cell>
        <Grid cols={3}>
          <Cell label="loading"><div style={{ width: "100%", border: "1px solid var(--m-line)", borderRadius: "var(--m-r-3)", overflow: "hidden", background: "var(--m-bg-2)", height: 160 }}><MetralyTable state="loading" /></div></Cell>
          <Cell label="empty"><div style={{ width: "100%", border: "1px solid var(--m-line)", borderRadius: "var(--m-r-3)", overflow: "hidden", background: "var(--m-bg-2)", height: 160 }}><MetralyTable state="empty" /></div></Cell>
          <Cell label="error · disconnected"><div style={{ width: "100%", border: "1px solid var(--m-line)", borderRadius: "var(--m-r-3)", overflow: "hidden", background: "var(--m-bg-2)", height: 160 }}><MetralyTable state="error" /></div></Cell>
        </Grid>
      </div>
    </div>
  );
}

function DropZoneBoard() {
  return (
    <div>
      <BoardTitle name="DashboardDropZone" slug="metraly/dashboard-dropzone" hardening="visual-ready" />
      <Grid cols={2}>
        <Cell label="idle"><div style={{ width: "100%" }}><DashboardDropZone state="idle" /></div></Cell>
        <Cell label="hover"><div style={{ width: "100%" }}><DashboardDropZone state="hover" /></div></Cell>
        <Cell label="active · drop pending"><div style={{ width: "100%" }}><DashboardDropZone state="active" /></div></Cell>
        <Cell label="rejected"><div style={{ width: "100%" }}><DashboardDropZone state="rejected" label="Cannot drop here" /></div></Cell>
      </Grid>
    </div>
  );
}

function ResizeBoard() {
  return (
    <div>
      <BoardTitle name="DashboardResizeHandle" slug="metraly/resize-handles" hardening="hardening" />
      <Grid cols={2}>
        <Cell label="default · selected"><div style={{ width: 280, position: "relative" }}><WidgetShell title="Latency p99" kind="chart/line" selected height={140}><div style={{padding:14, color:"var(--m-fg-3)", fontFamily:"var(--m-font-mono)", fontSize:11}}>chart…</div></WidgetShell></div></Cell>
        <Cell label="active · resizing"><div style={{ width: 280, position: "relative" }}><WidgetShell title="Latency p99" kind="chart/line" selected resizing height={140}><div style={{padding:14, color:"var(--m-fg-3)", fontFamily:"var(--m-font-mono)", fontSize:11}}>chart…</div></WidgetShell></div></Cell>
      </Grid>
    </div>
  );
}

function StateBoard() {
  return (
    <div style={{ padding: 24, display: "flex", flexDirection: "column", gap: 24, color: "var(--m-fg-1)" }}>
      <CheckboxBoard />
      <RadioBoard />
      <SwitchBoard />
      <SelectBoard />
      <TabsBoard />
      <StateBadgeBoard />
      <WidgetPickerBoard />
      <WidgetShellBoard />
      <TableBoard />
      <ToolbarBoard />
      <DropZoneBoard />
      <ResizeBoard />
    </div>
  );
}

Object.assign(window, { StateBoard, MetricCard });
