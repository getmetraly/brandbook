// app.jsx — Top-level shell: design canvas wrapping state board, editor, docs.
// Hosts Tweaks panel for accent / glow / density / pulse / edit-mode / live-sync.

const { useState: useStateApp, useEffect: useEffectApp } = React;

const APP_TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "cyan",
  "glow": 1,
  "density": "comfortable",
  "pulseWave": true,
  "showError": true,
  "showStale": true
}/*EDITMODE-END*/;

function ApplyTweaks({ tweaks }) {
  useEffectApp(() => {
    document.documentElement.setAttribute("data-density", tweaks.density);
    document.documentElement.setAttribute("data-glow", String(tweaks.glow));
    document.documentElement.setAttribute("data-pulse", tweaks.pulseWave ? "on" : "off");
  }, [tweaks.density, tweaks.glow, tweaks.pulseWave]);
  return null;
}

function App() {
  const [tweaks, setTweak] = useTweaks(APP_TWEAK_DEFAULTS);

  return (
    <>
      <ApplyTweaks tweaks={tweaks} />

      <DesignCanvas>
        <DCSection id="dashboard" title="Engineering Intelligence · Dashboard Editor" subtitle="Real DORA + flow + delivery widgets composed through the Metraly component system. Multi-file prototype (HTML + sibling .jsx + tokens.css) — not a single-file standalone bundle.">
          <DCArtboard id="editor" label="Delivery · all teams · edit mode" width={1360} height={920}>
            <div style={{ width: 1360, height: 920 }}>
              <DashboardEditor
                accent={tweaks.accent}
                showError={tweaks.showError}
                showStale={tweaks.showStale}
                showEmpty={true}
                livePulse={tweaks.pulseWave}
              />
            </div>
          </DCArtboard>
        </DCSection>

        <DCSection id="state-board" title="Component state board" subtitle="All twelve Metraly components × every relevant state. Source for visual review and regression. Hover / focus the controls — they really work.">
          <DCArtboard id="forms"   label="Form controls · 1–6" width={780} height={2000}>
            <div style={{ background: "var(--m-bg-0)", height: "100%", overflow: "auto" }} className="m-scroll">
              <FormBoardOnly />
            </div>
          </DCArtboard>
          <DCArtboard id="widgets" label="Widget surface · 7–12" width={780} height={2200}>
            <div style={{ background: "var(--m-bg-0)", height: "100%", overflow: "auto" }} className="m-scroll">
              <WidgetBoardOnly />
            </div>
          </DCArtboard>
        </DCSection>

        <DCSection id="docs" title="Design rationale · a11y · interaction · readiness" subtitle="Production hand-off notes. English. Token-named. Brandbook-aligned.">
          <DCArtboard id="docs" label="Hardening note" width={820} height={2400}>
            <div style={{ background: "var(--m-bg-0)", height: "100%", overflow: "auto" }} className="m-scroll">
              <Docs />
            </div>
          </DCArtboard>
        </DCSection>
      </DesignCanvas>

      <AppTweaksPanel tweaks={tweaks} setTweak={setTweak} />
    </>
  );
}

function FormBoardOnly() {
  return (
    <div style={{ padding: 24, display: "flex", flexDirection: "column", gap: 24 }}>
      <CheckboxBoard /><RadioBoard /><SwitchBoard /><SelectBoard /><TabsBoard /><StateBadgeBoard />
    </div>
  );
}
function WidgetBoardOnly() {
  return (
    <div style={{ padding: 24, display: "flex", flexDirection: "column", gap: 24 }}>
      <WidgetPickerBoard /><WidgetShellBoard /><TableBoard /><ToolbarBoard /><DropZoneBoard /><ResizeBoard />
    </div>
  );
}

function AppTweaksPanel({ tweaks, setTweak }) {
  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Brand">
        <TweakRadio label="Accent" value={tweaks.accent} onChange={(v) => setTweak("accent", v)}
          options={[{ value: "cyan", label: "Cyan" }, { value: "purple", label: "Purple" }]} />
        <TweakSelect label="Glow" value={String(tweaks.glow)} onChange={(v) => setTweak("glow", Number(v))}
          options={[{ value: "0", label: "Off" }, { value: "1", label: "Default" }, { value: "2", label: "Boosted" }]} />
        <TweakToggle label="Pulse-wave on" value={tweaks.pulseWave} onChange={(v) => setTweak("pulseWave", v)} />
      </TweakSection>
      <TweakSection label="Density">
        <TweakRadio label="Density" value={tweaks.density} onChange={(v) => setTweak("density", v)}
          options={[{ value: "comfortable", label: "Comfortable" }, { value: "compact", label: "Compact" }]} />
      </TweakSection>
      <TweakSection label="Editor scenario">
        <TweakToggle label="Show stale widget" value={tweaks.showStale} onChange={(v) => setTweak("showStale", v)} />
        <TweakToggle label="Show error / disconnected" value={tweaks.showError} onChange={(v) => setTweak("showError", v)} />
      </TweakSection>
    </TweaksPanel>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
