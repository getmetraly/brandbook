// docs.jsx — Design rationale, a11y, interaction rules, impl notes, readiness.
// Rendered as a tall artboard inside the design canvas.

function DocsBlock({ kicker, title, children }) {
  return (
    <section style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ fontFamily: "var(--m-font-mono)", fontSize: 10, color: "var(--m-cyan-500)", letterSpacing: "0.08em", textTransform: "uppercase" }}>{kicker}</span>
        <span style={{ flex: 1, height: 1, background: "linear-gradient(90deg, var(--m-line) 0%, transparent 100%)" }} />
      </div>
      <h2 style={{ margin: 0, fontSize: 18, color: "var(--m-fg-0)", fontWeight: 500, letterSpacing: "-0.005em" }}>{title}</h2>
      <div style={{ fontSize: 12, color: "var(--m-fg-1)", lineHeight: 1.6 }}>{children}</div>
    </section>
  );
}

const Code = ({ children }) => (
  <code style={{ fontFamily: "var(--m-font-mono)", fontSize: 11, background: "var(--m-bg-3)", color: "var(--m-cyan-400)", padding: "1px 5px", borderRadius: 3 }}>{children}</code>
);

function Bullets({ items }) {
  return (
    <ul style={{ margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 6 }}>
      {items.map((it, i) => (
        <li key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
          <span style={{ marginTop: 8, width: 4, height: 4, borderRadius: "50%", background: "var(--m-cyan-500)", flex: "0 0 auto" }} />
          <span>{it}</span>
        </li>
      ))}
    </ul>
  );
}

function ReadinessRow({ status, name, slug, note }) {
  const tone = status === "ready" ? "ok" : status === "preview" ? "purple" : "stale";
  const label = status === "ready" ? "Ready" : status === "preview" ? "Preview-only" : "Hardening";
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "120px 1fr 1fr",
      gap: 12, alignItems: "center",
      padding: "8px 10px",
      background: "var(--m-bg-2)",
      border: "1px solid var(--m-line-faint)",
      borderRadius: "var(--m-r-2)",
    }}>
      <StateBadge state={tone} label={label} withPulse={false} />
      <span style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}>
        <span style={{ color: "var(--m-fg-0)", fontSize: 12, fontWeight: 500 }}>{name}</span>
        <span style={{ color: "var(--m-fg-3)", fontSize: 10, fontFamily: "var(--m-font-mono)" }}>{slug}</span>
      </span>
      <span style={{ color: "var(--m-fg-2)", fontSize: 11 }}>{note}</span>
    </div>
  );
}

function Docs() {
  return (
    <div style={{ padding: 28, display: "flex", flexDirection: "column", gap: 28, color: "var(--m-fg-1)", maxWidth: 760 }}>

      <header style={{ display: "flex", flexDirection: "column", gap: 8, paddingBottom: 14, borderBottom: "1px solid var(--m-line)" }}>
        <span style={{ fontFamily: "var(--m-font-mono)", fontSize: 10, color: "var(--m-cyan-500)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Brandbook · Hardening note</span>
        <h1 style={{ margin: 0, fontSize: 28, color: "var(--m-fg-0)", fontWeight: 500, letterSpacing: "-0.01em" }}>Component state board &amp; dashboard editor</h1>
        <p style={{ margin: 0, color: "var(--m-fg-2)", fontSize: 13, lineHeight: 1.55 }}>
          Hardens the existing Metraly visual language into a production-ready interactive surface. Dark-by-default, telemetry-native, cyan as primary signal, purple as secondary depth. The protected <Code>/components</Code> baseline is unchanged; everything here lives under <Code>site/app/components/previews/</Code>.
        </p>
      </header>

      {/* ── Design rationale ─────────────────────────────────── */}
      <DocsBlock kicker="01 · Rationale" title="Why this looks the way it does">
        <Bullets items={[
          <>Dark by default. Background <Code>oklch(0.155 0.010 250)</Code> is desaturated cool-gray so cyan reads as signal, not background noise.</>,
          <>Cyan = operational signal (live, selected, focus, primary action). Purple = depth/accent (beta, secondary series, alternate accent). Status uses semantic green/amber/rose only when meaning is unambiguous.</>,
          <>Glow is functional, not decorative: 1 px focus ring + 8–16 px outer halo at ≤ 0.22 alpha. <Code>data-glow="0|1|2"</Code> lets ops disable it on low-contrast displays.</>,
          <>Pulse-wave is semantic. Allowed: live/unread, selected controls, badges, logo, telemetry dividers, chart accents. Forbidden: drag handles, ambient surface ornament. Drag uses neutral <Code>GripDots</Code>.</>,
          <>Density and motion are stable. Hover changes <em>border</em> and <em>background only</em> — never <Code>transform: translateY</Code>. Layout cannot bounce while you scan numbers.</>,
        ]} />
      </DocsBlock>

      {/* ── A11y ─────────────────────────────────────────────── */}
      <DocsBlock kicker="02 · Accessibility" title="Notes — non-negotiable">
        <Bullets items={[
          <>Every interactive element exposes <Code>:focus-visible</Code> via a single shared mixin <Code>--m-glow-focus</Code> (1 px solid cyan + 4 px halo). Ring renders <em>inside</em> the element via <Code>box-shadow</Code>, so no layout shift on focus.</>,
          <>Disabled = <Code>aria-disabled="true"</Code> + <Code>tabIndex=-1</Code> + <Code>pointer-events:none</Code> + ≤ 0.45 opacity. Disabled controls are unreachable by keyboard — they cannot trap focus.</>,
          <>Roles are honest: <Code>role="checkbox"</Code> with <Code>aria-checked="mixed"</Code> for indeterminate, <Code>role="switch"</Code> on switches, <Code>role="tablist/tab"</Code> on tabs, <Code>role="listbox/option"</Code> on selects. Radios share a <Code>name</Code>.</>,
          <>Status is communicated by colour <em>and</em> shape: <Code>StateBadge</Code> always pairs a coloured dot with text; <Code>StatusDot</Code> alone is informational only and is mirrored elsewhere.</>,
          <>Pulse-wave respects <Code>prefers-reduced-motion</Code> at runtime and honours the <Code>data-pulse="off"</Code> kill switch on <Code>html</Code>.</>,
          <>Tap targets ≥ 28 px (default density) / 32 px (comfortable). Drag-handle hit area ≥ 24 × 24 even though the visual grip is 9 px.</>,
          <>Contrast: body text <Code>--m-fg-1</Code> on <Code>--m-bg-0</Code> ≈ 12:1; secondary <Code>--m-fg-2</Code> ≈ 7:1; cyan on bg ≈ 8.5:1.</>,
        ]} />
      </DocsBlock>

      {/* ── Interaction rules ────────────────────────────────── */}
      <DocsBlock kicker="03 · Interaction rules" title="What can move, what can’t">
        <Bullets items={[
          <><strong>No vertical hover jumps.</strong> Hover may change <Code>border-color</Code>, <Code>background</Code>, <Code>color</Code>; it must not change <Code>transform</Code>, <Code>margin</Code>, <Code>height</Code>, or <Code>padding</Code>.</>,
          <><strong>Drag = grip dots only.</strong> Pulse-wave is never the drag affordance. Grip lives top-left of the widget header, with the title <em>after</em> it. Tooltip reads “Drag to move” — never preceded by a pulse-wave.</>,
          <><strong>Selection vs drag.</strong> Click selects (cyan ring + selection underline). Mousedown + move on the grip drags. Selection persists during drag; drop clears the dragging-state, retains selection.</>,
          <><strong>Resize.</strong> 8 handles appear only when a widget is selected or actively resizing. Handles sit on a 1-px cyan border, 8 × 8, with 8 px hit slop. Live size readout (e.g. <Code>4 × 2</Code>) shows in the widget footer during resize.</>,
          <><strong>Drop zones.</strong> Idle = dashed hairline. Hover = stronger hairline. Active = cyan + cyan-bg + flanking pulse-waves + “Release to add”. Rejected = rose + “Cannot drop here”.</>,
          <><strong>Empty &amp; error.</strong> Empty = monospace explainer + zero-event count. Error = inline reconnect button, <em>not</em> a modal. The widget shell stays in the grid.</>,
          <><strong>Live signal.</strong> One pulse-wave per discrete signal: toolbar sync chip, selected widget footer, unread row dot, selected tab. If everything pulses, nothing pulses — keep ≤ 5 visible at once.</>,
        ]} />
      </DocsBlock>

      {/* ── Implementation ───────────────────────────────────── */}
      <DocsBlock kicker="04 · Implementation" title="React / Next.js notes">
        <Bullets items={[
          <>Tokens live in <Code>tokens.css</Code> on <Code>:root</Code> as CSS custom properties — no Tailwind config dependency. <Code>data-density</Code>, <Code>data-glow</Code>, <Code>data-pulse</Code> attributes on <Code>html</Code> override at runtime. Add to <Code>app/globals.css</Code> via <Code>@import</Code>.</>,
          <>All Metraly components are client components (<Code>"use client"</Code>). They use only <Code>useState</Code>, <Code>useId</Code>, <Code>useMemo</Code> — no portal-based dropdown yet; <Code>MetralySelect</Code> renders absolutely-positioned children. Replace with a <Code>Popover</Code> primitive for production to handle clipping.</>,
          <><Code>WidgetShell</Code> is the canonical container. Compose every dashboard widget through it so state styling (selected / dragging / stale / error / empty / loading / unread) is consistent.</>,
          <>DnD: scaffold uses native HTML5 drag for the prototype. Production should switch to <Code>dnd-kit</Code> with the same visual contract: pickup uses <Code>GripDots</Code> handle, drop targets emit <Code>data-state="active|hover|idle|rejected"</Code>, and the dashboard owns the layout grid.</>,
          <>Layout grid: 12-column CSS grid, <Code>grid-auto-rows: minmax(150px, auto)</Code>, 12 px gutter. Widgets store <Code>{`{col, row, w, h}`}</Code> — match this in your persistence layer.</>,
          <>Animations: <Code>m-pulse</Code>, <Code>m-pulse-dot</Code>, <Code>m-shimmer</Code> are the only allowed keyframes. Reuse them; do not author per-component motion.</>,
          <>Naming: prefix all component classes / data attributes with <Code>m-</Code> to avoid collision with the <Code>/components</Code> baseline.</>,
        ]} />
      </DocsBlock>

      {/* ── Brandbook updates ────────────────────────────────── */}
      <DocsBlock kicker="05 · Brandbook updates" title="Suggested doc edits">
        <Bullets items={[
          <>Add <Code>design-system/components.md#state-matrix</Code> documenting the canonical state list per component (default · hover · focus-visible · active · selected · disabled · loading · empty · stale · error · unread · dragging · drop-target · resizing).</>,
          <>Add <Code>design-system/board-edit-mode.md#interaction-contract</Code>: grip-only drag rule, no-vertical-hover-jump rule, resize-handle visibility rule, drop-zone state machine.</>,
          <>Update <Code>brandbook/pulse-marker.md</Code> with the explicit allow-list (live, unread, selected, badges, logo, divider, chart accent) and deny-list (drag handles, generic ornament, modal chrome).</>,
          <>Add <Code>design-system/micro-telemetry-primitives.md#statusdot</Code>: state vocabulary <Code>ok | live | stale | err | new | idle</Code> and pulse rules (<Code>live</Code> and <Code>new</Code> pulse; the rest are static).</>,
          <>Add <Code>brandbook/glow-rules.md</Code>: focus glow vs selected glow vs ambient glow — all token-driven via <Code>--m-glow-focus</Code> / <Code>--m-glow-selected</Code> / <Code>--m-glow-purple</Code>.</>,
        ]} />
      </DocsBlock>

      {/* ── Readiness ────────────────────────────────────────── */}
      <DocsBlock kicker="06 · Readiness matrix" title="Ship · harden · preview-only">
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <ReadinessRow status="ready"   name="MetralyCheckbox"   slug="metraly/checkbox" note="Full state matrix covered. Indeterminate + error wired." />
          <ReadinessRow status="ready"   name="MetralyRadio"      slug="metraly/radio" note="Group + error states covered. Add roving-tabindex helper before ship." />
          <ReadinessRow status="ready"   name="MetralySwitch"     slug="metraly/switch" note="Cyan + purple accents. Loading state lives on the thumb." />
          <ReadinessRow status="ready"   name="StateBadge"        slug="metraly/state-badge" note="Full semantic palette + pulse opt-out." />
          <ReadinessRow status="visual"  name="WidgetPickerCard"  slug="metraly/widget-picker-card" note="Drag-source. Disabled requires source-config copy + connect-source CTA." />
          <ReadinessRow status="visual"  name="WidgetShell"        slug="metraly/widget-shell" note="Canonical container. All EI widget bodies (DORA, flow, review, CI) compose through it." />
          <ReadinessRow status="visual"  name="DashboardToolbar"   slug="metraly/dashboard-toolbar" note="Tabs + search + sync chip + edit-toggle + add-widget. Layout stable." />
          <ReadinessRow status="visual"  name="DashboardDropZone"  slug="metraly/dashboard-dropzone" note="Idle / hover / active / reject — all visual states final. No pulse-wave." />
          <ReadinessRow status="ready"   name="StatusDot · PulseWave · Sparkline" slug="metraly/telemetry-primitives" note="Telemetry primitives — pure, token-driven, reduced-motion-aware." />
          <ReadinessRow status="hardening" name="MetralySelect"    slug="metraly/select" note="Replace inline popover with a portal-based Popover primitive (clipping risk in dense grids)." />
          <ReadinessRow status="hardening" name="MetralyTabs"      slug="metraly/tabs" note="Add roving-tabindex + arrow-key nav. Underline already animated cleanly." />
          <ReadinessRow status="hardening" name="MetralyTable"     slug="metraly/table" note="Sticky header + selection wired. Sorting + virtualisation pending for &gt;200 rows." />
          <ReadinessRow status="hardening" name="DashboardResizeHandle" slug="metraly/resize-handles" note="Visual + cursor map final. Snap-to-grid + min-size guards pending." />
          <ReadinessRow status="hardening" name="ChartLine · CycleTimeBars · DoraOverview" slug="metraly/ei-widgets" note="Composed from primitives. Need real adapters for GitHub / GitLab / Jenkins / Linear before ship." />
          <ReadinessRow status="preview" name="WIP per engineer"   slug="metraly/flow-wip" note="Source connector not built — keep disabled in picker until adapter lands." />
        </div>
        <p style={{ marginTop: 14, color: "var(--m-fg-3)", fontSize: 11, fontStyle: "italic" }}>Readiness mirrors the State Board and the Engineering Intelligence editor — every component shipped here is referenced in at least one of the two surfaces.</p>
      </DocsBlock>

      {/* ── Implementation handoff ────────────────────────────── */}
      <DocsBlock kicker="07 · Implementation handoff" title="Use as visual reference only">
        <div style={{ display: "flex", flexDirection: "column", gap: 8, fontSize: 12, color: "var(--m-fg-1)", lineHeight: 1.6 }}>
          <p style={{ margin: 0 }}>This prototype is a <strong>visual reference only</strong>. It demonstrates interaction, state machine rules, and the Metraly visual system in action. Do not use it as a code base.</p>
          <div style={{ background: "var(--m-cyan-bg)", border: "1px solid var(--m-line-faint)", borderRadius: "var(--m-r-2)", padding: 10, fontSize: 11, color: "var(--m-fg-2)" }}>
            <strong style={{ color: "var(--m-cyan-500)" }}>Handoff location:</strong> Convert to proper Next.js/TypeScript components inside <Code>getmetraly/brandbook/site/app/components/previews/</Code>. <strong>Do not</strong> modify protected <Code>/components</Code> folder.
          </div>
          <div>
            <strong>Ready for implementation now:</strong>
            <ul style={{ margin: "4px 0 0 20px", paddingLeft: 0 }}>
              <li>Form controls (Checkbox, Radio, Switch, Select, Tabs) — low complexity.</li>
              <li>Telemetry primitives (StatusDot, PulseWave, Sparkline) — pure visual functions.</li>
              <li>StateBadge — semantic state + reduced-motion support.</li>
            </ul>
          </div>
          <div>
            <strong>Hardening phase (wire before ship):</strong>
            <ul style={{ margin: "4px 0 0 20px", paddingLeft: 0 }}>
              <li>Select &amp; Tabs — add roving-tabindex + keyboard navigation.</li>
              <li>WidgetShell, DashboardToolbar — finalize edit-mode UX contract.</li>
              <li>DashboardResizeHandle — add snap-to-grid, min-size guards, dnd-kit binding.</li>
              <li>MetralyTable — row selection, sticky headers, virtualisation for &gt;200 rows.</li>
            </ul>
          </div>
          <div>
            <strong>Dependencies (preview-only until built):</strong>
            <ul style={{ margin: "4px 0 0 20px", paddingLeft: 0 }}>
              <li>Real source adapters for DORA metrics (GitHub, GitLab, Jenkins, Linear, etc.).</li>
              <li>Drag-and-drop composition (dnd-kit or native drag/drop with state machine).</li>
              <li>Real dashboard persistence (localStorage or backend).</li>
            </ul>
          </div>
          <p style={{ margin: 0, fontSize: 11, color: "var(--m-fg-3)" }}>Refer to the <strong>State Board</strong> and <strong>Engineering Intelligence Editor</strong> artboards as visual specifications. The <strong>Tweaks panel</strong> (bottom right) exposes design levers (accent, glow, density) — use these to validate implementation against multiple contexts.</p>
        </div>
      </DocsBlock>
    </div>
  );
}

Object.assign(window, { Docs });
