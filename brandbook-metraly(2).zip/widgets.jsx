// widgets.jsx — Dashboard editor widgets & layout primitives.
// Components:
//   WidgetPickerCard, DashboardWidget (a.k.a WidgetShell), MetralyTable,
//   DashboardToolbar, DashboardDropZone, DashboardResizeHandle.
//
// Drag affordance == GripDots only. Pulse-wave is reserved for telemetry
// signal (live, selected, fresh data). Hover never shifts layout.

const { useState: useStateW, useEffect: useEffectW } = React;

// ─── WidgetPickerCard ───────────────────────────────────────────
function WidgetPickerCard({ icon = "metric", title, kind, description, state = "default", onClick, dragging = false }) {
  // states: default | hover (CSS) | focus | selected | disabled | dragging | new
  const isDisabled = state === "disabled";
  const isSelected = state === "selected";
  const isNew = state === "new";
  const isLoading = state === "loading";

  return (
    <button className="m-focusable" disabled={isDisabled}
      onClick={!isDisabled ? onClick : undefined}
      data-state={state} data-dragging={dragging || undefined}
      style={{
        position: "relative",
        display: "flex", flexDirection: "column", gap: 8,
        padding: "10px 12px",
        textAlign: "left",
        background: isSelected ? "var(--m-cyan-bg)" : "var(--m-bg-2)",
        border: `1px solid ${isSelected ? "var(--m-cyan-500)" : "var(--m-line)"}`,
        borderRadius: "var(--m-r-3)",
        color: isDisabled ? "var(--m-fg-4)" : "var(--m-fg-1)",
        opacity: isDisabled ? 0.55 : dragging ? 0.6 : 1,
        cursor: isDisabled ? "not-allowed" : dragging ? "grabbing" : "grab",
        transition: "background var(--m-dur-2), border-color var(--m-dur-2)",
        boxShadow: isSelected ? "var(--m-glow-selected)" : "none",
        fontFamily: "var(--m-font-ui)",
        width: "100%",
        transform: dragging ? "scale(0.97) rotate(-1deg)" : "none",
        outline: dragging ? "1px dashed var(--m-cyan-500)" : "none",
      }}
      onMouseEnter={(e) => { if (!isDisabled && !isSelected) { e.currentTarget.style.background = "var(--m-bg-3)"; e.currentTarget.style.borderColor = "var(--m-line-strong)"; } }}
      onMouseLeave={(e) => { if (!isSelected) { e.currentTarget.style.background = "var(--m-bg-2)"; e.currentTarget.style.borderColor = "var(--m-line)"; } }}
    >
      <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{
          width: 24, height: 24, borderRadius: "var(--m-r-2)",
          background: isSelected ? "var(--m-cyan-500)" : "var(--m-bg-3)",
          color: isSelected ? "var(--m-bg-0)" : "var(--m-fg-2)",
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          flex: "0 0 auto",
        }}>
          {isLoading ? <span className="m-spin" style={{ width: 11, height: 11, border: "1.4px solid var(--m-cyan-500)", borderTopColor: "transparent", borderRadius: "50%", animation: "m-spin 0.7s linear infinite" }} /> : <Icon name={icon} size={13} />}
        </span>
        <span style={{ display: "flex", flexDirection: "column", minWidth: 0, flex: 1 }}>
          <span style={{ fontSize: "var(--m-fs-12)", color: "var(--m-fg-0)", fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{title}</span>
          {kind && <span style={{ fontSize: "var(--m-fs-9)", color: "var(--m-fg-3)", fontFamily: "var(--m-font-mono)", letterSpacing: "0.03em", textTransform: "uppercase" }}>{kind}</span>}
        </span>
        {isNew && <StateBadge state="new" label="New" />}
        {isSelected && <PulseWave width={20} height={8} />}
      </span>
      {description && <span style={{ fontSize: "var(--m-fs-11)", color: "var(--m-fg-2)", lineHeight: 1.4 }}>{description}</span>}
    </button>
  );
}

// ─── WidgetShell · DashboardWidget ──────────────────────────────
// One canonical widget container with all states.
function WidgetShell({
  title, kind, status = "live", state = "default",
  selected = false, dragging = false, resizing = false,
  isStale = false, isError = false, isLoading = false, isEmpty = false,
  unread = false,
  width, height = 200, children, footer, controls,
  onClick, onSelect, accent = "cyan",
  showGrip = true,
}) {
  // resolve overall mode
  const mode =
    isError ? "error" :
    isLoading ? "loading" :
    isEmpty ? "empty" :
    isStale ? "stale" :
    state;

  const accentTone = accent === "purple" ? "var(--m-purple-500)" : "var(--m-cyan-500)";
  const accentGlow = accent === "purple" ? "var(--m-purple-glow)" : "var(--m-cyan-glow)";

  return (
    <div data-widget data-state={mode} data-selected={selected || undefined}
      onClick={onSelect}
      style={{
        position: "relative",
        display: "flex", flexDirection: "column",
        background: "var(--m-bg-2)",
        border: `1px solid ${
          mode === "error" ? "var(--m-err)" :
          selected ? accentTone :
          mode === "stale" ? "var(--m-warn)" :
          "var(--m-line)"
        }`,
        borderRadius: "var(--m-r-4)",
        boxShadow: selected ? `0 0 0 1px ${accentTone}, 0 0 16px -4px ${accentGlow}` : "none",
        opacity: dragging ? 0.55 : 1,
        transform: dragging ? "scale(0.99) rotate(-0.4deg)" : "none",
        transition: "border-color var(--m-dur-2), box-shadow var(--m-dur-2)",
        width: width || "100%",
        height,
        overflow: "hidden",
        cursor: dragging ? "grabbing" : "default",
      }}
    >
      {/* Header */}
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        padding: "8px 10px",
        borderBottom: "1px solid var(--m-line-faint)",
        flex: "0 0 auto",
        minHeight: 36,
      }}>
        {showGrip && (
          <span title="Drag to move" aria-label="Drag to move" tabIndex={0} className="m-focusable"
            style={{
              cursor: "grab", padding: "4px 2px",
              borderRadius: 4, color: "var(--m-fg-3)",
              display: "inline-flex", alignItems: "center",
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = "var(--m-bg-3)"}
            onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
          ><GripDots size={9} /></span>
        )}
        <span style={{ display: "flex", flexDirection: "column", minWidth: 0, flex: 1 }}>
          <span style={{ fontSize: "var(--m-fs-12)", color: "var(--m-fg-0)", fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{title}</span>
          {kind && <span style={{ fontSize: "var(--m-fs-9)", color: "var(--m-fg-3)", fontFamily: "var(--m-font-mono)", letterSpacing: "0.03em", textTransform: "uppercase" }}>{kind}</span>}
        </span>
        {/* status chip */}
        {mode === "error" ? <StateBadge state="error" label="Disconnected" /> :
         mode === "loading" ? <StateBadge state="info" label="Loading" /> :
         mode === "stale" ? <StateBadge state="stale" label="Stale 4m" /> :
         mode === "empty" ? <StateBadge state="info" label="No data" /> :
         unread ? <StateBadge state="new" label="New" /> :
         <StateBadge state="live" label="Live" />}
        {controls}
      </div>

      {/* Body */}
      <div style={{ flex: 1, position: "relative", display: "flex", flexDirection: "column", minHeight: 0 }}>
        {mode === "loading" ? <LoadingSkeleton /> :
         mode === "error" ? <ErrorState /> :
         mode === "empty" ? <EmptyState /> :
         children}
      </div>

      {/* Footer */}
      {footer && (
        <div style={{
          padding: "6px 10px",
          borderTop: "1px solid var(--m-line-faint)",
          fontSize: "var(--m-fs-10)",
          color: "var(--m-fg-3)",
          fontFamily: "var(--m-font-mono)",
          display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8,
          flex: "0 0 auto",
        }}>{footer}</div>
      )}

      {/* Resize handles — appear only when selected/resizing in editor */}
      {(selected || resizing) && <ResizeHandles resizing={resizing} accent={accent} />}

      {/* Selected-row pulse divider (subtle, semantic) */}
      {selected && !dragging && (
        <span aria-hidden="true" style={{ position: "absolute", left: 0, right: 0, bottom: -1, height: 1.5, background: `linear-gradient(90deg, transparent, ${accentTone}, transparent)`, opacity: 0.7 }} />
      )}
    </div>
  );
}

function LoadingSkeleton() {
  const bar = (w) => (
    <div style={{
      height: 10, width: w,
      background: "linear-gradient(90deg, var(--m-bg-3) 0%, var(--m-bg-4) 50%, var(--m-bg-3) 100%)",
      backgroundSize: "200% 100%",
      animation: "m-shimmer 1.4s linear infinite",
      borderRadius: 4,
    }} />
  );
  return (
    <div style={{ padding: 14, display: "flex", flexDirection: "column", gap: 10, flex: 1 }}>
      {bar("60%")}
      {bar("85%")}
      {bar("45%")}
      <div style={{ flex: 1 }} />
      {bar("70%")}
    </div>
  );
}

function ErrorState() {
  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8, padding: 16 }}>
      <div style={{
        width: 28, height: 28, borderRadius: "50%",
        background: "var(--m-err-bg)", color: "var(--m-err)",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        border: "1px solid var(--m-err)",
      }}><Icon name="x" size={14} /></div>
      <div style={{ fontSize: "var(--m-fs-12)", color: "var(--m-fg-1)" }}>Source disconnected</div>
      <div style={{ fontSize: "var(--m-fs-10)", color: "var(--m-fg-3)", fontFamily: "var(--m-font-mono)" }}>last sync 12m ago · retrying…</div>
      <button className="m-focusable" style={{
        marginTop: 4,
        background: "transparent", color: "var(--m-cyan-500)",
        border: "1px solid var(--m-cyan-500)",
        padding: "4px 10px", borderRadius: "var(--m-r-2)",
        fontSize: "var(--m-fs-11)", fontFamily: "var(--m-font-ui)",
        cursor: "pointer",
      }}>Reconnect</button>
    </div>
  );
}

function EmptyState() {
  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6, padding: 16, color: "var(--m-fg-3)" }}>
      <Icon name="metric" size={20} />
      <div style={{ fontSize: "var(--m-fs-11)" }}>No telemetry in this range</div>
      <div style={{ fontSize: "var(--m-fs-10)", fontFamily: "var(--m-font-mono)" }}>0 events · widen the time window</div>
    </div>
  );
}

// ─── ResizeHandles ──────────────────────────────────────────────
function ResizeHandles({ resizing, accent = "cyan" }) {
  const tone = accent === "purple" ? "var(--m-purple-500)" : "var(--m-cyan-500)";
  const handle = (pos) => (
    <span data-resize={pos} style={{
      position: "absolute", width: 8, height: 8,
      background: "var(--m-bg-0)",
      border: `1px solid ${tone}`,
      borderRadius: 2,
      boxShadow: resizing ? `0 0 8px -1px ${tone}` : "none",
      cursor: pos.includes("nw") || pos.includes("se") ? "nwse-resize" :
              pos.includes("ne") || pos.includes("sw") ? "nesw-resize" :
              pos === "n" || pos === "s" ? "ns-resize" : "ew-resize",
      ...handlePos(pos),
    }} />
  );
  return (
    <>
      {["nw","n","ne","e","se","s","sw","w"].map(p => <React.Fragment key={p}>{handle(p)}</React.Fragment>)}
    </>
  );
}
function handlePos(p) {
  const off = -4;
  switch (p) {
    case "nw": return { top: off, left: off };
    case "n":  return { top: off, left: "calc(50% - 4px)" };
    case "ne": return { top: off, right: off };
    case "e":  return { top: "calc(50% - 4px)", right: off };
    case "se": return { bottom: off, right: off };
    case "s":  return { bottom: off, left: "calc(50% - 4px)" };
    case "sw": return { bottom: off, left: off };
    case "w":  return { top: "calc(50% - 4px)", left: off };
  }
}
function DashboardResizeHandle(props) { return <ResizeHandles {...props} />; }

// ─── DashboardDropZone ──────────────────────────────────────────
function DashboardDropZone({ state = "idle", label = "Drop widget here", height = 96, accent = "cyan" }) {
  // states: idle | hover | active (drop pending) | rejected | empty
  const tone = state === "rejected" ? "var(--m-err)" :
               state === "active" ? (accent === "purple" ? "var(--m-purple-500)" : "var(--m-cyan-500)") :
               state === "hover" ? "var(--m-line-strong)" :
               "var(--m-line)";
  const bg = state === "active" ? "var(--m-cyan-bg)" :
             state === "rejected" ? "var(--m-err-bg)" :
             "transparent";
  return (
    <div data-state={state} style={{
      height,
      border: `1.5px dashed ${tone}`,
      borderRadius: "var(--m-r-4)",
      background: bg,
      display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
      color: state === "rejected" ? "var(--m-err)" : state === "active" ? "var(--m-cyan-500)" : "var(--m-fg-3)",
      fontSize: "var(--m-fs-11)",
      fontFamily: "var(--m-font-mono)", letterSpacing: "0.04em", textTransform: "uppercase",
      transition: "border-color var(--m-dur-2), background var(--m-dur-2)",
      position: "relative",
    }}>
      {state === "rejected" ? <Icon name="x" size={14} /> : <Icon name="plus" size={14} />}
      <span>{state === "rejected" ? "Cannot drop here" : state === "active" ? "Release to add" : label}</span>
    </div>
  );
}

// ─── MetralyTable ───────────────────────────────────────────────
function MetralyTable({ columns = [], rows = [], state = "default", selectedRows = [], onSelectRow, density = "comfortable", livePulseRows = [] }) {
  // states: default | loading | empty | error | with-selected | with-unread
  const rowH = density === "compact" ? 28 : 34;
  if (state === "loading") {
    return (
      <div style={{ padding: 12 }}>
        {[...Array(5)].map((_, i) => (
          <div key={i} style={{
            height: rowH - 4, marginBottom: 4,
            background: "linear-gradient(90deg, var(--m-bg-3) 0%, var(--m-bg-4) 50%, var(--m-bg-3) 100%)",
            backgroundSize: "200% 100%", animation: "m-shimmer 1.4s linear infinite",
            borderRadius: 3, opacity: 1 - i * 0.12,
          }} />
        ))}
      </div>
    );
  }
  if (state === "empty") {
    return <EmptyState />;
  }
  if (state === "error") {
    return <ErrorState />;
  }
  return (
    <div style={{ width: "100%", overflow: "auto", flex: 1, minHeight: 0 }} className="m-scroll">
      <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "var(--m-font-ui)", fontSize: "var(--m-fs-11)" }}>
        <thead>
          <tr style={{ background: "var(--m-bg-1)", position: "sticky", top: 0, zIndex: 1 }}>
            {columns.map((c, i) => (
              <th key={c.key} style={{
                textAlign: c.align || "left",
                padding: "0 10px",
                height: rowH,
                color: "var(--m-fg-3)", fontWeight: 500,
                fontFamily: "var(--m-font-mono)", fontSize: "var(--m-fs-10)",
                letterSpacing: "0.04em", textTransform: "uppercase",
                borderBottom: "1px solid var(--m-line)",
                whiteSpace: "nowrap",
                width: c.width,
              }}>{c.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => {
            const isSelected = selectedRows.includes(r.id ?? i);
            const isUnread = livePulseRows.includes(r.id ?? i);
            return (
              <tr key={r.id ?? i}
                onClick={() => onSelectRow?.(r.id ?? i)}
                style={{
                  background: isSelected ? "var(--m-cyan-bg)" : "transparent",
                  borderBottom: "1px solid var(--m-line-faint)",
                  cursor: onSelectRow ? "pointer" : "default",
                  transition: "background var(--m-dur-1)",
                }}
                onMouseEnter={(e) => { if (!isSelected) e.currentTarget.style.background = "var(--m-bg-3)"; }}
                onMouseLeave={(e) => { if (!isSelected) e.currentTarget.style.background = "transparent"; }}
              >
                {columns.map((c, ci) => {
                  const v = r[c.key];
                  return (
                    <td key={c.key} style={{
                      padding: "0 10px", height: rowH,
                      color: c.mono ? "var(--m-fg-1)" : "var(--m-fg-1)",
                      fontFamily: c.mono ? "var(--m-font-mono)" : "var(--m-font-ui)",
                      fontSize: c.mono ? "var(--m-fs-11)" : "var(--m-fs-11)",
                      textAlign: c.align || "left",
                      whiteSpace: "nowrap",
                      verticalAlign: "middle",
                      borderLeft: ci === 0 && isSelected ? `2px solid var(--m-cyan-500)` : "2px solid transparent",
                    }}>
                      {ci === 0 && isUnread && (
                        <span style={{ display: "inline-flex", alignItems: "center", gap: 6, marginRight: 6, verticalAlign: "middle" }}>
                          <StatusDot state="new" size={6} withPulse />
                        </span>
                      )}
                      {c.render ? c.render(v, r) : v}
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ─── DashboardToolbar ───────────────────────────────────────────
// Two-row layout: tabs on top (scroll horizontally if needed), actions below.
// Prevents tab counts from colliding with search / edit / add at narrower
// widths.
function DashboardToolbar({ tabs, activeTab, onTabChange, search, onSearch, syncState = "live", onAddWidget, editMode = false, onToggleEdit }) {
  return (
    <div style={{
      display: "flex", flexDirection: "column", gap: 8,
      padding: "8px 12px",
      background: "var(--m-bg-1)",
      border: "1px solid var(--m-line)",
      borderRadius: "var(--m-r-3)",
    }}>
      {/* row 1 — tabs (scroll inside their own row, never push siblings) */}
      <div style={{
        display: "flex", alignItems: "center",
        overflowX: "auto", overflowY: "hidden",
        scrollbarWidth: "none",
        margin: "-2px 0", padding: "2px 0",
        borderBottom: "1px solid var(--m-line-faint)",
      }}>
        <MetralyTabs tabs={tabs} value={activeTab} onChange={onTabChange} livePulse={true} />
      </div>

      {/* row 2 — search + sync chip + edit + add */}
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{
          position: "relative", display: "inline-flex", alignItems: "center",
          background: "var(--m-bg-2)", border: "1px solid var(--m-line)",
          borderRadius: "var(--m-r-2)",
          padding: "0 10px",
          height: "var(--m-control-h)",
          flex: "1 1 240px", minWidth: 180, maxWidth: 360,
        }}>
          <span style={{ color: "var(--m-fg-3)", display: "inline-flex", marginRight: 6 }}><Icon name="search" size={12} /></span>
          <input value={search} onChange={(e) => onSearch?.(e.target.value)} placeholder="Search widgets, metrics…"
            className="m-focusable"
            style={{
              flex: 1, minWidth: 0, height: "100%",
              background: "transparent", border: "none", outline: "none",
              color: "var(--m-fg-1)",
              fontSize: "var(--m-fs-12)", fontFamily: "var(--m-font-ui)",
            }} />
          <span style={{
            fontFamily: "var(--m-font-mono)", fontSize: "var(--m-fs-9)",
            color: "var(--m-fg-3)",
            background: "var(--m-bg-3)", padding: "1px 5px", borderRadius: 3,
          }}>⌘K</span>
        </div>

        <span style={{ flex: 1 }} />

        {/* sync state */}
      <span style={{
        display: "inline-flex", alignItems: "center", gap: 6,
        height: "var(--m-control-h)", padding: "0 10px",
        background: "var(--m-bg-2)", border: "1px solid var(--m-line)",
        borderRadius: "var(--m-r-2)",
        fontFamily: "var(--m-font-mono)", fontSize: "var(--m-fs-10)",
        color: syncState === "error" ? "var(--m-err)" : syncState === "stale" ? "var(--m-warn)" : "var(--m-fg-2)",
        letterSpacing: "0.03em",
      }}>
        <StatusDot state={syncState === "error" ? "err" : syncState === "stale" ? "stale" : "live"} size={6} withPulse={syncState === "live"} />
        {syncState === "live" ? "Live · 30s" : syncState === "stale" ? "Stale 4m" : "Disconnected"}
        {syncState === "live" && <PulseWave width={18} height={6} />}
      </span>

      {/* edit toggle */}
      <button className="m-focusable" onClick={onToggleEdit}
        title={editMode ? "Exit edit mode" : "Edit dashboard"}
        style={{
          height: "var(--m-control-h)", padding: "0 10px",
          background: editMode ? "var(--m-cyan-bg)" : "var(--m-bg-2)",
          border: `1px solid ${editMode ? "var(--m-cyan-500)" : "var(--m-line)"}`,
          color: editMode ? "var(--m-cyan-500)" : "var(--m-fg-1)",
          borderRadius: "var(--m-r-2)",
          fontSize: "var(--m-fs-11)", fontFamily: "var(--m-font-ui)",
          display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer",
          transition: "background var(--m-dur-2), border-color var(--m-dur-2)",
        }}>
        <Icon name="grid" size={12} />
        {editMode ? "Editing" : "Edit"}
      </button>

      {/* primary action */}
      <button className="m-focusable" onClick={onAddWidget}
        style={{
          height: "var(--m-control-h)", padding: "0 12px",
          background: "var(--m-cyan-500)", color: "var(--m-bg-0)",
          border: "1px solid var(--m-cyan-500)",
          borderRadius: "var(--m-r-2)",
          fontSize: "var(--m-fs-11)", fontFamily: "var(--m-font-ui)", fontWeight: 500,
          display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer",
          boxShadow: "0 0 12px -3px var(--m-cyan-glow)",
          transition: "background var(--m-dur-2), box-shadow var(--m-dur-2)",
        }}
        onMouseEnter={(e) => e.currentTarget.style.background = "var(--m-cyan-400)"}
        onMouseLeave={(e) => e.currentTarget.style.background = "var(--m-cyan-500)"}
      >
        <Icon name="plus" size={12} />
        Add widget
      </button>
      </div>
    </div>
  );
}

Object.assign(window, { WidgetPickerCard, WidgetShell, DashboardWidget: WidgetShell, MetralyTable, DashboardToolbar, DashboardDropZone, DashboardResizeHandle, ResizeHandles, LoadingSkeleton, EmptyState, ErrorState });
