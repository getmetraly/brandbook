// primitives.jsx — Metraly micro-telemetry primitives
// Tiny, semantic, reusable. NEVER use PulseWave as a drag handle —
// drag uses GripDots (neutral, non-living).

const { useState, useEffect, useRef, useMemo } = React;

// ─── PulseWave ──────────────────────────────────────────────────
// Animated horizontal sine — only for: live, selected, unread,
// telemetry dividers, logo marks, chart accents.
function PulseWave({ width = 32, height = 10, color = "var(--m-cyan-500)", speed = 1.6, opacity = 1, role = "presentation" }) {
  // 1.5 cycles, pre-flattened path
  const path = useMemo(() => {
    const w = width, h = height, mid = h / 2, amp = h * 0.32;
    const segs = 24;
    let d = `M0 ${mid}`;
    for (let i = 1; i <= segs; i++) {
      const x = (i / segs) * w;
      const y = mid + Math.sin((i / segs) * Math.PI * 3) * amp;
      d += ` L${x.toFixed(2)} ${y.toFixed(2)}`;
    }
    return d;
  }, [width, height]);
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} role={role} style={{ display: "inline-block", verticalAlign: "middle" }}>
      <path className="m-pulse" d={path} stroke={color} strokeWidth="1.25" fill="none" strokeLinecap="round" style={{ animation: `m-pulse ${speed}s var(--m-ease) infinite`, transformOrigin: "center", opacity }} />
    </svg>
  );
}

// ─── GripDots ───────────────────────────────────────────────────
// Neutral 6-dot grip. The ONLY allowed drag affordance.
function GripDots({ size = 10, tone = "var(--m-fg-3)" }) {
  const r = 1;
  const dots = [[0,0],[0,1],[0,2],[1,0],[1,1],[1,2]];
  return (
    <svg width={size} height={size * 1.4} viewBox="0 0 4 6" aria-hidden="true" style={{ display: "block" }}>
      {dots.map(([x,y], i) => <circle key={i} cx={x*2+1} cy={y*2+1} r={r} fill={tone} />)}
    </svg>
  );
}

// ─── StatusDot ──────────────────────────────────────────────────
// Tiny semantic state dot. Pulses only when state === 'live' or 'unread'.
function StatusDot({ state = "ok", size = 8, withPulse = false }) {
  const tone = {
    ok:    "var(--m-ok)",
    live:  "var(--m-ok)",
    stale: "var(--m-warn)",
    err:   "var(--m-err)",
    idle:  "var(--m-fg-3)",
    new:   "var(--m-cyan-500)",
    selected: "var(--m-cyan-500)",
  }[state] || "var(--m-fg-3)";
  const animates = withPulse || state === "live" || state === "new";
  return (
    <span style={{ position: "relative", display: "inline-flex", width: size, height: size, alignItems: "center", justifyContent: "center" }}>
      {animates && (
        <span className="m-pulse-dot" style={{
          position: "absolute", inset: 0, borderRadius: "50%",
          background: tone, opacity: 0.4,
          animation: "m-pulse-dot 1.6s var(--m-ease) infinite",
          transform: "scale(1.8)",
        }} />
      )}
      <span style={{ width: size, height: size, borderRadius: "50%", background: tone, boxShadow: animates ? `0 0 6px -1px ${tone}` : "none" }} />
    </span>
  );
}

// ─── Sparkline ──────────────────────────────────────────────────
function Sparkline({ data, width = 120, height = 28, color = "var(--m-cyan-500)", area = true }) {
  const { d, fill } = useMemo(() => {
    if (!data?.length) return { d: "", fill: "" };
    const min = Math.min(...data), max = Math.max(...data);
    const range = max - min || 1;
    const dx = width / (data.length - 1);
    const pts = data.map((v, i) => [i * dx, height - 2 - ((v - min) / range) * (height - 4)]);
    const d = "M" + pts.map(([x,y]) => `${x.toFixed(1)} ${y.toFixed(1)}`).join(" L");
    const fill = d + ` L${width} ${height} L0 ${height} Z`;
    return { d, fill };
  }, [data, width, height]);
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ display: "block" }}>
      {area && <path d={fill} fill={color} opacity="0.10" />}
      <path d={d} stroke={color} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// ─── ChartLine — simple multi-series line chart ─────────────────
function ChartLine({ series, width = 540, height = 200, withGrid = true, accent = "cyan" }) {
  const colors = accent === "purple" ? ["var(--m-purple-500)", "var(--m-cyan-500)"] : ["var(--m-cyan-500)", "var(--m-purple-500)"];
  const allVals = series.flatMap(s => s.data);
  const max = Math.max(...allVals), min = Math.min(...allVals);
  const range = max - min || 1;
  const padL = 28, padR = 12, padT = 12, padB = 22;
  const w = width - padL - padR, h = height - padT - padB;
  const dx = w / (series[0].data.length - 1);
  const yTicks = [0, 0.25, 0.5, 0.75, 1].map(t => min + t * range);
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ display: "block" }}>
      {withGrid && yTicks.map((v, i) => {
        const y = padT + h - (i / 4) * h;
        return (
          <g key={i}>
            <line x1={padL} x2={width - padR} y1={y} y2={y} stroke="var(--m-line-faint)" strokeDasharray="2 3" />
            <text x={padL - 6} y={y + 3} fontSize="9" fill="var(--m-fg-3)" textAnchor="end" fontFamily="var(--m-font-mono)">{Math.round(v)}</text>
          </g>
        );
      })}
      {series.map((s, si) => {
        const pts = s.data.map((v, i) => [padL + i * dx, padT + h - ((v - min) / range) * h]);
        const d = "M" + pts.map(([x,y]) => `${x.toFixed(1)} ${y.toFixed(1)}`).join(" L");
        const fill = d + ` L${padL + w} ${padT + h} L${padL} ${padT + h} Z`;
        const c = colors[si % colors.length];
        return (
          <g key={si}>
            <path d={fill} fill={c} opacity="0.08" />
            <path d={d} stroke={c} strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </g>
        );
      })}
      {/* x-axis ticks */}
      {[0, 0.25, 0.5, 0.75, 1].map((t, i) => {
        const x = padL + t * w;
        const labels = ["−24h", "−18h", "−12h", "−6h", "now"];
        return <text key={i} x={x} y={height - 6} fontSize="9" fill="var(--m-fg-3)" textAnchor="middle" fontFamily="var(--m-font-mono)">{labels[i]}</text>;
      })}
    </svg>
  );
}

// ─── Telemetry divider — semantic horizontal pulse separator ────
function TelemetryDivider({ live = false, label }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0" }}>
      <div style={{ flex: 1, height: 1, background: "linear-gradient(90deg, transparent, var(--m-line) 20%, var(--m-line) 80%, transparent)" }} />
      {live && <PulseWave width={28} height={8} color="var(--m-cyan-500)" />}
      {label && <span style={{ fontFamily: "var(--m-font-mono)", fontSize: 10, color: "var(--m-fg-3)", letterSpacing: "0.04em", textTransform: "uppercase" }}>{label}</span>}
      {live && <PulseWave width={28} height={8} color="var(--m-cyan-500)" />}
      <div style={{ flex: 1, height: 1, background: "linear-gradient(90deg, transparent, var(--m-line) 20%, var(--m-line) 80%, transparent)" }} />
    </div>
  );
}

// ─── Generic icons ──────────────────────────────────────────────
const Icon = ({ name, size = 14 }) => {
  const paths = {
    check: "M3 7 L6 10 L11 4",
    chevron: "M4 6 L7 9 L10 6",
    chevronR: "M6 4 L9 7 L6 10",
    chevronL: "M9 4 L6 7 L9 10",
    plus: "M7 3 V11 M3 7 H11",
    minus: "M3 7 H11",
    x: "M4 4 L10 10 M10 4 L4 10",
    search: "M6.2 6.2 m-3.5 0 a3.5 3.5 0 1 0 7 0 a3.5 3.5 0 1 0 -7 0 M9 9 L12 12",
    grid: "M2 2 H6 V6 H2 Z M8 2 H12 V6 H8 Z M2 8 H6 V12 H2 Z M8 8 H12 V12 H8 Z",
    chart: "M2 11 L5 7 L8 9 L12 3",
    table: "M2 3 H12 V11 H2 Z M2 6 H12 M5 6 V11",
    bell:  "M7 2 a3 3 0 0 0 -3 3 v2 l-1 2 h8 l-1 -2 v-2 a3 3 0 0 0 -3 -3 Z M6 12 a1 1 0 0 0 2 0",
    lightning: "M8 1 L3 8 H7 L6 13 L11 6 H7 Z",
    refresh: "M11 6 a4 4 0 1 1 -1 -2.8 M11 2 V6 H7",
    settings: "M7 4.5 a2.5 2.5 0 1 0 0 5 a2.5 2.5 0 0 0 0 -5 Z M7 1 V3 M7 11 V13 M11.5 7 H13 M1 7 H2.5 M10.2 3.8 L11.3 2.7 M2.7 11.3 L3.8 10.2 M10.2 10.2 L11.3 11.3 M2.7 2.7 L3.8 3.8",
    drag: "M5 3 V11 M9 3 V11 M3 5 H11 M3 9 H11",
    move: "M7 1 L7 13 M1 7 L13 7 M5 3 L7 1 L9 3 M5 11 L7 13 L9 11 M3 5 L1 7 L3 9 M11 5 L13 7 L11 9",
    db: "M7 2 c-3 0 -5 1 -5 2 v6 c0 1 2 2 5 2 s5 -1 5 -2 V4 c0 -1 -2 -2 -5 -2 Z M2 4 c0 1 2 2 5 2 s5 -1 5 -2 M2 7 c0 1 2 2 5 2 s5 -1 5 -2",
    server: "M2 3 H12 V6 H2 Z M2 8 H12 V11 H2 Z M4.5 4.5 H4.6 M4.5 9.5 H4.6",
    api: "M2 7 H4 M10 7 H12 M5 4 V10 M9 4 V10 M5 5 H9 M5 9 H9",
    log: "M3 3 H11 V11 H3 Z M5 5 H9 M5 7 H9 M5 9 H7",
    metric: "M3 11 V8 M6 11 V5 M9 11 V7 M12 11 V3",
    folder: "M2 4 H6 L7 5 H12 V11 H2 Z",
    user: "M7 7 a2.5 2.5 0 1 0 0 -5 a2.5 2.5 0 0 0 0 5 Z M2 13 c0 -3 2 -5 5 -5 s5 2 5 5",
    expand: "M3 3 H6 M3 3 V6 M11 3 H8 M11 3 V6 M3 11 H6 M3 11 V8 M11 11 H8 M11 11 V8",
    pause: "M5 3 V11 M9 3 V11",
    play: "M5 3 L11 7 L5 11 Z",
    star: "M7 2 L8.5 5.5 L12 6 L9.5 8.5 L10 12 L7 10 L4 12 L4.5 8.5 L2 6 L5.5 5.5 Z",
  };
  return (
    <svg width={size} height={size} viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" style={{ display: "block", flex: "0 0 auto" }}>
      <path d={paths[name] || paths.plus} />
    </svg>
  );
};

Object.assign(window, { PulseWave, GripDots, StatusDot, Sparkline, ChartLine, TelemetryDivider, Icon });
